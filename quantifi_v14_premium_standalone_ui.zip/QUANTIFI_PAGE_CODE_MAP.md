# Quantifi page code map

Use the Next.js pages as thin route files. Put the heavy UI inside `src/components/quantifi/ui.tsx` and the demo/static data inside `src/data/quantifi.ts`.

## 1. `src/app/(dashboard)/page.tsx`

```tsx
import { HomePageContent } from "@/components/quantifi/ui";

export default function Home() {
  return <HomePageContent />;
}
```

## 2. `src/app/portfolio/page.tsx`

```tsx
import { HomePageContent } from "@/components/quantifi/ui";

export default function PortfolioPage() {
  return <HomePageContent />;
}
```

## 3. `src/app/ideas/page.tsx`

```tsx
import { InvestingIdeasPageContent } from "@/components/quantifi/ui";

export default function IdeasPage() {
  return <InvestingIdeasPageContent />;
}
```

## 4. `src/app/news/page.tsx`

```tsx
import { NewsImpactContent } from "@/components/quantifi/ui";

export default function NewsPage() {
  return <NewsImpactContent />;
}
```

## 5. `src/app/insider-activity/page.tsx`

```tsx
import { InsiderActivityContent } from "@/components/quantifi/ui";

export default function InsiderActivityPage() {
  return <InsiderActivityContent />;
}
```

## 6. `src/app/explore/page.tsx`

```tsx
import { ExploreIdeasSection, PageShell } from "@/components/quantifi/ui";

export default function ExplorePage() {
  return (
    <PageShell
      eyebrow="Discovery"
      title="Explore Companies / ETFs"
      description="Browse companies and ETFs outside your current portfolio by theme, market, sector and risk lens."
    >
      <ExploreIdeasSection compact />
    </PageShell>
  );
}
```

## 7. `src/app/famous-takes/page.tsx`

```tsx
import { FamousTakesContent } from "@/components/quantifi/ui";

export default function FamousTakesPage() {
  return <FamousTakesContent />;
}
```

## 8. `src/app/stock-analysis/page.tsx`

```tsx
import { StockAnalysisContent } from "@/components/quantifi/ui";

export default function StockAnalysisPage() {
  return <StockAnalysisContent />;
}
```

## 9. `src/app/watchlist/page.tsx`

```tsx
import { WatchlistContent } from "@/components/quantifi/ui";

export default function WatchlistPage() {
  return <WatchlistContent />;
}
```

## 10. `src/config/site.tsx`

```tsx
import {
  BellRing,
  BriefcaseBusiness,
  ChartNoAxesCombined,
  Eye,
  Newspaper,
  Search,
  Sparkles,
  type LucideIcon,
  Users,
} from "lucide-react";

export type SiteConfig = typeof siteConfig;
export type Navigation = {
  icon: LucideIcon;
  name: string;
  href: string;
};

export const siteConfig = {
  title: "Quantifi",
  description:
    "AI-first market intelligence for portfolio stocks, trading ideas, news impact, insider activity and famous market takes.",
};

export const navigations: Navigation[] = [
  { icon: BriefcaseBusiness, name: "Portfolio Stocks", href: "/" },
  { icon: Sparkles, name: "Trading Ideas", href: "/ideas" },
  { icon: Newspaper, name: "News Impact", href: "/news" },
  { icon: Users, name: "Insider Activity", href: "/insider-activity" },
  { icon: Search, name: "Explore", href: "/explore" },
  { icon: Eye, name: "Famous Takes", href: "/famous-takes" },
  { icon: ChartNoAxesCombined, name: "Stock Analysis", href: "/stock-analysis" },
  { icon: BellRing, name: "Watchlist", href: "/watchlist" },
];
```

## Shared files powering the pages

These are already included in the project:

- `src/components/quantifi/ui.tsx` — all section components: portfolio, diversification, investing ideas, news impact, insider activity, famous takes, stock analysis, watchlist and footer.
- `src/data/quantifi.ts` — demo/static data for holdings, investing ideas, news, affected stocks, insider activity, famous takes, data-source roadmap and footer links.
- `src/app/layout.tsx` — wraps all pages in the side nav and footer.

## Why pages are short

The route page files should stay short. If every page contains hundreds of lines of UI, the project becomes hard to maintain. The correct structure is:

```text
page.tsx = route only
ui.tsx = reusable components
quantifi.ts = page data
site.tsx = nav + metadata
```
