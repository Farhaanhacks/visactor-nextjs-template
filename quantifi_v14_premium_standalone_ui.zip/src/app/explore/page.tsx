import { ExplorePageContent } from "@/components/quantifi/ui";

export default function ExplorePage() {
  return <ExplorePageContent />;
}
