"use client";

import Container from "../container";

export default function TopNav({ title }: { title: string }) {
  return (
    <Container className="hidden h-0 overflow-hidden border-none bg-[#050507] text-white">
      <h1>{title}</h1>
    </Container>
  );
}
