"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { navigations } from "@/config/site";
import { cn } from "@/lib/utils";

export default function Navigation() {
  const pathname = usePathname();
  return (
    <nav className="flex flex-grow flex-col gap-y-1 p-3">
      {navigations.map((navigation) => {
        const Icon = navigation.icon;
        const active = pathname === navigation.href || (navigation.href !== "/" && pathname.startsWith(navigation.href));
        return (
          <Link
            key={navigation.name}
            href={navigation.href}
            className={cn(
              "group flex items-center rounded-2xl px-3 py-3 text-sm font-bold transition",
              active
                ? "border border-amber-300/40 bg-amber-300 text-slate-950 shadow-[0_0_28px_rgba(252,211,77,0.20)]"
                : "border border-transparent bg-transparent text-slate-300 hover:border-white/10 hover:bg-white/[0.06] hover:text-white",
            )}
          >
            <Icon size={17} className={cn("mr-3", active ? "text-slate-950" : "text-amber-300 group-hover:text-amber-200")} />
            <span>{navigation.name}</span>
          </Link>
        );
      })}
    </nav>
  );
}
