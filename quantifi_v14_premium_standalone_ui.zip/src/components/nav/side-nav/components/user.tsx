import { ChevronDown } from "lucide-react";

export default function User() {
  return (
    <div className="flex h-20 items-center border-b border-white/10 px-3">
      <div className="flex w-full items-center justify-between rounded-2xl border border-white/10 bg-white/[0.04] px-3 py-2">
        <div className="flex items-center">
          <div className="mr-3 grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br from-amber-300 via-emerald-300 to-sky-400 text-base font-black text-slate-950 shadow-[0_0_28px_rgba(252,211,77,0.22)]">
            Q
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-black text-white">Quantifi</span>
            <span className="text-xs text-slate-500">Market beta</span>
          </div>
        </div>
        <ChevronDown size={16} className="text-slate-400" />
      </div>
    </div>
  );
}
