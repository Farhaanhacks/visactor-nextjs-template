import Link from "next/link";
import { ArrowRight } from "lucide-react";

export default function VisActor() {
  return (
    <Link
      href="/ideas"
      className="relative m-3 overflow-hidden rounded-3xl border border-amber-300/25 bg-gradient-to-br from-amber-300/15 via-white/[0.04] to-cyan-300/10 p-4 shadow-[0_20px_60px_rgba(0,0,0,0.35)]"
    >
      <div className="absolute right-[-2rem] top-[-2rem] h-24 w-24 rounded-full bg-amber-300/20 blur-2xl" />
      <span className="relative text-xs font-black uppercase tracking-[0.2em] text-amber-300">Beta access</span>
      <div className="relative mt-2 text-lg font-black text-white">₹30 unlock</div>
      <span className="relative mt-1 block text-xs leading-5 text-slate-400">Trading ideas, news impact and insider activity</span>
      <div className="relative mt-4 inline-flex items-center gap-2 text-xs font-black text-amber-200">
        Explore now <ArrowRight size={14} />
      </div>
    </Link>
  );
}
