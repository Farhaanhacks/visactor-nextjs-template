"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useMemo, useState } from "react";
import type { ReactNode } from "react";
import {
  Activity,
  ArrowRight,
  Bell,
  BrainCircuit,
  Building2,
  ChevronRight,
  Eye,
  Flame,
  Globe2,
  Layers3,
  LineChart,
  Newspaper,
  Radar,
  Search,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  Users,
  WalletCards,
  Zap,
} from "lucide-react";

const navItems = [
  { label: "Portfolio", href: "/", icon: WalletCards },
  { label: "Ideas", href: "/ideas", icon: Sparkles },
  { label: "News", href: "/news", icon: Newspaper },
  { label: "Insider", href: "/insider-activity", icon: Users },
  { label: "Explore", href: "/explore", icon: Search },
  { label: "Famous Takes", href: "/famous-takes", icon: Eye },
  { label: "Stock Analysis", href: "/stock-analysis", icon: LineChart },
  { label: "Watchlist", href: "/watchlist", icon: Bell },
];

const holdings = [
  { ticker: "NVDA", company: "Nvidia", sector: "Technology", industry: "Semiconductors", weight: 46.1, value: "US$25.6k", move7d: "+2.4%", move1y: "+138.0%", risk: "AI valuation risk", color: "from-cyan-300 to-blue-500" },
  { ticker: "AMZN", company: "Amazon", sector: "Consumer Discretionary", industry: "General Merchandise & Cloud", weight: 53.9, value: "US$30.0k", move7d: "+0.7%", move1y: "+13.8%", risk: "Cloud + consumer cycle", color: "from-amber-300 to-orange-500" },
];

const ideas = [
  { title: "AI Infrastructure Watch", desc: "Semis, cloud and data-center stocks reacting to AI capex expectations.", tickers: ["NVDA", "AMD", "MSFT", "ORCL", "SMH"], tag: "Hot", theme: "AI" },
  { title: "Insider Buying", desc: "Companies where management/directors are showing fresh activity.", tickers: ["MSFT", "META", "TSLA"], tag: "8 alerts", theme: "Signals" },
  { title: "Dividend Powerhouses", desc: "Cash-flow names with consistent dividends and defensive behavior.", tickers: ["KO", "PG", "JNJ", "PEP"], tag: "Income", theme: "Dividends" },
  { title: "Undervalued Companies", desc: "Stocks that appear cheap relative to fundamentals, margins or expected earnings.", tickers: ["GOOGL", "PYPL", "BABA"], tag: "21 new", theme: "Value" },
  { title: "Nuclear Energy", desc: "Uranium, SMRs, utilities and power infrastructure linked to AI energy demand.", tickers: ["CCJ", "CEG", "UEC", "URA"], tag: "Theme", theme: "Energy" },
  { title: "Cybersecurity", desc: "Security software names with secular enterprise demand.", tickers: ["CRWD", "PANW", "ZS"], tag: "Quality", theme: "Software" },
];

const news = [
  { headline: "AI capex concerns rise as investors question returns on data-center spending", source: "Market News", impact: "Mixed", affected: ["NVDA", "AMD", "MSFT", "AMZN", "GOOGL"], why: "AI infrastructure winners may still be vulnerable if customers fail to show enough return on spending.", score: 86 },
  { headline: "Cloud companies expand AI partnerships and chip-purchase commitments", source: "Global Markets", impact: "Positive", affected: ["NVDA", "ORCL", "MSFT", "AMZN"], why: "Large commitments support AI demand, but the app should watch whether this is organic or financing-driven.", score: 74 },
  { headline: "Retail and e-commerce stocks react to consumer spending data", source: "Economic Desk", impact: "Mixed", affected: ["AMZN", "WMT", "COST", "TGT"], why: "Consumer names can move together when inflation, spending or margin expectations change.", score: 61 },
];

const insider = [
  { ticker: "NVDA", type: "Insider Selling", person: "Director / Officer", value: "US$4.2m", signal: "Monitor", note: "Selling is not automatically bearish. Check whether it is routine or unusually large." },
  { ticker: "AMZN", type: "Insider Activity", person: "Executive", value: "US$1.1m", signal: "Neutral", note: "No major red flag unless repeated selling or pledge-like behavior appears." },
  { ticker: "MSFT", type: "Insider Buying", person: "Director", value: "US$780k", signal: "Positive", note: "Insider buying can suggest confidence, but must be checked with valuation and earnings." },
];

const famousTakeTickers = ["NVDA", "AMD", "PLTR", "MSFT", "ORCL", "QQQ", "SMH"];

function cn(...classes: Array<string | false | undefined | null>) {
  return classes.filter(Boolean).join(" ");
}

function Shell({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  return (
    <main className="min-h-screen overflow-hidden bg-[#030305] text-white selection:bg-amber-300 selection:text-black">
      <div className="pointer-events-none fixed inset-0 -z-10 bg-[radial-gradient(circle_at_15%_8%,rgba(245,211,93,0.20),transparent_28%),radial-gradient(circle_at_85%_5%,rgba(56,189,248,0.18),transparent_30%),radial-gradient(circle_at_65%_80%,rgba(16,185,129,0.12),transparent_30%)]" />
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#030305]/80 backdrop-blur-2xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 laptop:px-8">
          <Link href="/" className="flex items-center gap-3">
            <div className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-amber-300 via-emerald-300 to-sky-400 font-black text-black shadow-[0_0_40px_rgba(252,211,77,0.35)]">Q</div>
            <div>
              <div className="text-lg font-black tracking-tight">Quantifi</div>
              <div className="text-[11px] font-bold uppercase tracking-[0.22em] text-white/40">Market beta</div>
            </div>
          </Link>

          <nav className="hidden items-center gap-1 rounded-full border border-white/10 bg-white/[0.04] p-1 laptop:flex">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = pathname === item.href || (item.href !== "/" && pathname.startsWith(item.href));
              return (
                <Link key={item.href} href={item.href} className={cn("flex items-center gap-2 rounded-full px-3 py-2 text-xs font-extrabold transition", active ? "bg-amber-300 text-black" : "text-white/55 hover:bg-white/10 hover:text-white")}>
                  <Icon size={14} />
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <Link href="/ideas" className="hidden rounded-full bg-white px-4 py-2 text-sm font-black text-black shadow-[0_10px_40px_rgba(255,255,255,0.14)] transition hover:scale-[1.02] tablet:inline-flex">
            Unlock ₹30 beta
          </Link>
        </div>
      </header>
      <TickerTape />
      {children}
      <Footer />
    </main>
  );
}

function TickerTape() {
  const ticks = ["NVDA +2.4%", "AMZN +0.7%", "AI Capex Watch", "3 Insider Alerts", "Burry AI Bubble Lens", "News Impact Live", "Explore ETFs"];
  return (
    <div className="border-b border-white/10 bg-gradient-to-r from-amber-300/10 via-emerald-300/5 to-sky-400/10">
      <div className="mx-auto flex max-w-7xl gap-2 overflow-x-auto px-4 py-2 laptop:px-8">
        {ticks.map((tick) => <span key={tick} className="shrink-0 rounded-full border border-white/10 bg-black/40 px-3 py-1 text-xs font-bold text-white/75">{tick}</span>)}
      </div>
    </div>
  );
}

function PageHero({ eyebrow, title, description, children }: { eyebrow: string; title: string; description: string; children?: ReactNode }) {
  return (
    <section className="relative mx-auto max-w-7xl px-4 py-10 laptop:px-8 laptop:py-14">
      <div className="absolute right-8 top-10 hidden rounded-full border border-amber-300/20 bg-amber-300/10 px-4 py-2 text-xs font-black uppercase tracking-[0.2em] text-amber-200 laptop:block">Demo data · Premium UI</div>
      <div className="max-w-4xl">
        <div className="mb-4 text-sm font-black uppercase tracking-[0.38em] text-amber-300">{eyebrow}</div>
        <h1 className="text-4xl font-black leading-[0.95] tracking-[-0.05em] text-white tablet:text-6xl laptop:text-7xl">{title}</h1>
        <p className="mt-6 max-w-3xl text-lg font-semibold leading-8 text-white/55">{description}</p>
      </div>
      {children}
    </section>
  );
}

function Card({ children, className, onClick }: { children: ReactNode; className?: string; onClick?: () => void }) {
  return (
    <div onClick={onClick} className={cn("group rounded-[2rem] border border-white/10 bg-white/[0.045] p-5 shadow-[0_20px_80px_rgba(0,0,0,0.28)] backdrop-blur-xl transition duration-300 hover:-translate-y-1 hover:border-amber-300/45 hover:bg-white/[0.07]", onClick && "cursor-pointer", className)}>
      {children}
    </div>
  );
}

function Pill({ children, tone = "neutral" }: { children: ReactNode; tone?: "neutral" | "gold" | "green" | "blue" | "red" }) {
  return <span className={cn("inline-flex rounded-full border px-3 py-1 text-xs font-black", tone === "gold" ? "border-amber-300/30 bg-amber-300/15 text-amber-200" : tone === "green" ? "border-emerald-300/30 bg-emerald-300/10 text-emerald-200" : tone === "blue" ? "border-sky-300/30 bg-sky-300/10 text-sky-200" : tone === "red" ? "border-red-300/30 bg-red-300/10 text-red-200" : "border-white/10 bg-white/[0.06] text-white/65")}>{children}</span>;
}

function StatCard({ label, value, note, icon: Icon }: { label: string; value: string; note: string; icon: typeof Activity }) {
  return (
    <Card className="relative overflow-hidden">
      <div className="absolute right-[-1.5rem] top-[-1.5rem] h-24 w-24 rounded-full bg-amber-300/10 blur-2xl" />
      <div className="mb-8 flex h-11 w-11 items-center justify-center rounded-2xl bg-white/10 text-amber-200"><Icon size={20} /></div>
      <div className="text-sm font-bold text-white/45">{label}</div>
      <div className="mt-2 text-3xl font-black tracking-tight text-white">{value}</div>
      <div className="mt-2 text-sm font-semibold text-white/45">{note}</div>
    </Card>
  );
}

function PortfolioCards() {
  const [selected, setSelected] = useState(holdings[0].ticker);
  const selectedHolding = holdings.find((h) => h.ticker === selected) ?? holdings[0];
  return (
    <section className="mx-auto max-w-7xl px-4 pb-10 laptop:px-8">
      <div className="grid grid-cols-1 gap-4 tablet:grid-cols-2 laptop:grid-cols-4">
        <StatCard label="Portfolio Value" value="US$55.6k" note="Demo portfolio" icon={WalletCards} />
        <StatCard label="Top Exposure" value="AMZN 53.9%" note="Concentration watch" icon={Radar} />
        <StatCard label="AI Exposure" value="46.1%" note="Through NVDA" icon={BrainCircuit} />
        <StatCard label="Insider Alerts" value="3" note="Activity to review" icon={Bell} />
      </div>

      <div className="mt-6 grid grid-cols-1 gap-5 laptop:grid-cols-3">
        {holdings.map((holding) => (
          <Card key={holding.ticker} onClick={() => setSelected(holding.ticker)} className={cn(selected === holding.ticker && "border-amber-300/60 bg-amber-300/[0.08]")}>
            <div className="flex items-start justify-between">
              <div>
                <div className="text-3xl font-black tracking-tight">{holding.ticker}</div>
                <div className="mt-1 text-sm font-semibold text-white/45">{holding.company}</div>
              </div>
              <Pill tone="gold">{holding.weight}%</Pill>
            </div>
            <div className={cn("mt-6 h-2 rounded-full bg-gradient-to-r", holding.color)} style={{ width: `${Math.min(100, holding.weight + 20)}%` }} />
            <div className="mt-6 grid grid-cols-2 gap-5 text-sm">
              <Info label="Sector" value={holding.sector} />
              <Info label="Industry" value={holding.industry} />
              <Info label="7D" value={holding.move7d} good />
              <Info label="1Y" value={holding.move1y} good />
            </div>
          </Card>
        ))}
        <Card className="bg-gradient-to-br from-amber-300/20 via-white/[0.04] to-sky-300/10">
          <Pill tone="gold">Selected</Pill>
          <h3 className="mt-5 text-3xl font-black">{selectedHolding.ticker} Lens</h3>
          <p className="mt-3 text-sm font-semibold leading-6 text-white/55">{selectedHolding.risk}. Use this as the focused company for Stock Analysis, news impact and insider activity.</p>
          <Link href="/stock-analysis" className="mt-6 inline-flex items-center gap-2 rounded-full bg-amber-300 px-4 py-2 text-sm font-black text-black">Open Stock Analysis <ArrowRight size={16} /></Link>
        </Card>
      </div>
    </section>
  );
}

function Info({ label, value, good }: { label: string; value: string; good?: boolean }) {
  return <div><div className="text-white/35">{label}</div><div className={cn("mt-1 font-black", good ? "text-emerald-300" : "text-white")}>{value}</div></div>;
}

function DiversificationSection() {
  return (
    <section className="mx-auto max-w-7xl px-4 py-10 laptop:px-8">
      <SectionHeader title="Diversification" desc="A visual check for hidden concentration across sectors, industries, holdings and revenue exposure." />
      <Card className="overflow-hidden">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3"><h3 className="text-2xl font-black">Industry Flow</h3><Pill tone="gold">Portfolio → Sector → Industry → Ticker</Pill></div>
        <div className="space-y-4">
          {holdings.map((h) => (
            <div key={h.ticker} className="grid grid-cols-12 items-center gap-2 text-xs font-black tablet:text-sm">
              <div className="col-span-3 rounded-2xl bg-amber-300 px-3 py-4 text-black">Portfolio {h.weight}%</div>
              <div className="col-span-3 rounded-2xl bg-amber-200/80 px-3 py-4 text-black">{h.sector}</div>
              <div className="col-span-4 rounded-2xl bg-[#8e7742] px-3 py-4 text-white">{h.industry}</div>
              <div className="col-span-2 rounded-2xl border border-white/10 bg-white/5 px-3 py-4 text-center text-white">{h.ticker}</div>
            </div>
          ))}
        </div>
      </Card>
      <div className="mt-5 grid grid-cols-1 gap-5 laptop:grid-cols-2">
        <Card><h3 className="text-2xl font-black">Holdings Split</h3><Bars data={holdings.map((h) => ({ label: h.ticker, value: h.weight }))} /></Card>
        <Card><h3 className="text-2xl font-black">Revenue Geography</h3><Bars data={[{ label: "Not Reported", value: 53.9 }, { label: "North America", value: 34.2 }, { label: "Asia-Pacific", value: 11.2 }, { label: "Other", value: 0.7 }]} /></Card>
      </div>
    </section>
  );
}

function Bars({ data }: { data: Array<{ label: string; value: number }> }) {
  return <div className="mt-6 space-y-4">{data.map((d) => <div key={d.label}><div className="mb-2 flex justify-between text-sm font-bold"><span className="text-white/70">{d.label}</span><span>{d.value}%</span></div><div className="h-3 overflow-hidden rounded-full bg-white/10"><div className="h-full rounded-full bg-gradient-to-r from-amber-300 via-emerald-300 to-sky-400" style={{ width: `${d.value}%` }} /></div></div>)}</div>;
}

function SectionHeader({ title, desc }: { title: string; desc: string }) {
  return <div className="mb-6"><h2 className="text-3xl font-black tracking-tight tablet:text-4xl">{title}</h2><p className="mt-2 max-w-3xl text-sm font-semibold leading-6 text-white/45">{desc}</p></div>;
}

function ExploreIdeasSection({ compact = false }: { compact?: boolean }) {
  const [filter, setFilter] = useState("All");
  const filters = ["All", "AI", "Signals", "Dividends", "Value", "Energy", "Software"];
  const visible = ideas.filter((i) => filter === "All" || i.theme === filter).slice(0, compact ? 3 : 99);
  return (
    <section className="mx-auto max-w-7xl px-4 py-10 laptop:px-8">
      <SectionHeader title="Explore Companies / ETFs" desc="Beautiful discovery cards that create the feeling of a premium terminal even before paid data is connected." />
      <div className="mb-5 flex gap-2 overflow-x-auto">{filters.map((f) => <button key={f} onClick={() => setFilter(f)} className={cn("rounded-full px-4 py-2 text-sm font-black transition", filter === f ? "bg-amber-300 text-black" : "border border-white/10 bg-white/[0.04] text-white/60 hover:text-white")}>{f}</button>)}</div>
      <div className="grid grid-cols-1 gap-5 tablet:grid-cols-2 laptop:grid-cols-3">
        {visible.map((idea, idx) => (
          <Card key={idea.title} className="relative min-h-[290px] overflow-hidden">
            <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-br from-amber-300/40 via-emerald-300/20 to-sky-400/30" />
            <div className="absolute right-6 top-6 grid h-20 w-20 place-items-center rounded-full border border-white/10 bg-black/35 backdrop-blur-xl"><span className="text-2xl font-black">{idx + 1}</span></div>
            <div className="relative pt-32">
              <div className="mb-3"><Pill tone="gold">{idea.tag}</Pill></div>
              <h3 className="text-2xl font-black leading-tight">{idea.title}</h3>
              <p className="mt-3 text-sm font-semibold leading-6 text-white/50">{idea.desc}</p>
              <div className="mt-5 flex flex-wrap gap-2">{idea.tickers.map((t) => <Pill key={t}>{t}</Pill>)}</div>
            </div>
          </Card>
        ))}
      </div>
    </section>
  );
}

function NewsPreviewSection() {
  const [selected, setSelected] = useState(news[0]);
  return (
    <section className="mx-auto max-w-7xl px-4 py-10 laptop:px-8">
      <SectionHeader title="News Impact + Stocks Affected" desc="Clickable news cards that explain what moved, which tickers are affected, and why the headline matters." />
      <div className="grid grid-cols-1 gap-5 laptop:grid-cols-3">
        <div className="space-y-4 laptop:col-span-2">
          {news.map((item) => <Card key={item.headline} onClick={() => setSelected(item)} className={cn(selected.headline === item.headline && "border-amber-300/60 bg-amber-300/[0.08]")}><div className="flex items-center justify-between gap-3"><Pill>{item.source}</Pill><Pill tone={item.impact === "Positive" ? "green" : "gold"}>{item.impact}</Pill></div><h3 className="mt-4 text-xl font-black leading-7">{item.headline}</h3><p className="mt-2 text-sm font-semibold leading-6 text-white/50">{item.why}</p></Card>)}
        </div>
        <Card className="sticky top-28 h-fit bg-gradient-to-br from-amber-300/15 to-sky-400/10">
          <div className="flex items-center justify-between"><h3 className="text-2xl font-black">Stocks affected</h3><Pill tone="blue">Impact {selected.score}</Pill></div>
          <div className="mt-5 flex flex-wrap gap-2">{selected.affected.map((t) => <Pill key={t} tone="gold">{t}</Pill>)}</div>
          <p className="mt-5 text-sm font-semibold leading-6 text-white/55">{selected.why}</p>
          <button className="mt-6 w-full rounded-2xl bg-white px-4 py-3 text-sm font-black text-black">Open impact map</button>
        </Card>
      </div>
    </section>
  );
}

export function InsiderActivityContent() {
  const [mode, setMode] = useState("All");
  const modes = ["All", "Positive", "Monitor", "Neutral"];
  const rows = insider.filter((r) => mode === "All" || r.signal === mode);
  return <Shell><PageHero eyebrow="Insider Activity" title="Track what insiders are doing before it becomes obvious." description="Promoter, director and executive activity is not a buy/sell signal on its own — but it is a powerful research layer." /><section className="mx-auto max-w-7xl px-4 pb-16 laptop:px-8"><div className="mb-5 flex gap-2 overflow-x-auto">{modes.map((m) => <button key={m} onClick={() => setMode(m)} className={cn("rounded-full px-4 py-2 text-sm font-black", mode === m ? "bg-amber-300 text-black" : "border border-white/10 bg-white/[0.04] text-white/60")}>{m}</button>)}</div><div className="grid grid-cols-1 gap-5 laptop:grid-cols-3">{rows.map((row) => <Card key={`${row.ticker}-${row.type}`}><div className="flex justify-between"><div className="text-3xl font-black">{row.ticker}</div><Pill tone={row.signal === "Positive" ? "green" : row.signal === "Monitor" ? "gold" : "neutral"}>{row.signal}</Pill></div><div className="mt-5 text-xl font-black text-amber-200">{row.type}</div><div className="mt-2 text-sm text-white/45">{row.person}</div><div className="mt-5 text-sm"><span className="text-white/40">Value: </span><b>{row.value}</b></div><p className="mt-4 text-sm font-semibold leading-6 text-white/55">{row.note}</p></Card>)}</div></section></Shell>;
}

export function FamousTakesContent() {
  const [view, setView] = useState("Burry");
  return <Shell><PageHero eyebrow="Famous Takes" title="Market legends, translated into stocks affected." description="Turn big investor views into clear watchlists, risks and affected tickers." /><section className="mx-auto max-w-7xl px-4 pb-16 laptop:px-8"><div className="mb-5 flex gap-2"><button onClick={() => setView("Burry")} className={cn("rounded-full px-4 py-2 text-sm font-black", view === "Burry" ? "bg-amber-300 text-black" : "border border-white/10 bg-white/[0.04] text-white/60")}>Michael Burry AI Bubble</button><button onClick={() => setView("Vendor")} className={cn("rounded-full px-4 py-2 text-sm font-black", view === "Vendor" ? "bg-amber-300 text-black" : "border border-white/10 bg-white/[0.04] text-white/60")}>Vendor Financing Loop</button></div><div className="grid grid-cols-1 gap-5 laptop:grid-cols-2"><Card className="bg-gradient-to-br from-amber-300/15 to-red-400/10"><h2 className="text-3xl font-black">{view === "Burry" ? "Michael Burry’s AI Bubble Lens" : "Vendor Financing / Circular AI Money"}</h2><p className="mt-5 text-base font-semibold leading-8 text-white/60">{view === "Burry" ? "The concern is not that AI is useless. The concern is that investors may be paying too much for AI infrastructure companies before actual cash returns are proven." : "Vendor financing happens when companies fund customers or partners who then buy their products. In AI, money can move around the ecosystem and make demand look stronger than it really is."}</p><div className="mt-6 flex flex-wrap gap-2">{famousTakeTickers.map((t) => <Pill key={t} tone="gold">{t}</Pill>)}</div></Card><Card><h3 className="text-2xl font-black">Investor takeaway</h3><div className="mt-5 space-y-3 text-sm font-semibold leading-6 text-white/60"><div>• This is a risk lens, not a direct sell signal.</div><div>• Check free cash flow against AI capex commitments.</div><div>• Watch debt, customer concentration and related financing.</div><div>• If your portfolio is AI-heavy, diversification matters.</div></div></Card></div></section></Shell>;
}

export function InvestingIdeasPageContent() { return <Shell><PageHero eyebrow="Investing Ideas" title="Discover ideas before they become obvious." description="Themes, insider activity, famous takes and market stories packaged into clear research baskets." /><ExploreIdeasSection /></Shell>; }
export function ExplorePageContent() { return <Shell><PageHero eyebrow="Explore" title="Browse companies and ETFs by theme." description="Find ideas by AI, dividends, value, energy, software and market signals." /><ExploreIdeasSection /></Shell>; }
export function NewsImpactContent() { return <Shell><PageHero eyebrow="News Impact" title="Every headline should show the stocks affected." description="Do not just read news. Understand what tickers, sectors and portfolios may move because of it." /><NewsPreviewSection /></Shell>; }
export function StockAnalysisContent() { const [tab, setTab] = useState("Overview"); const tabs = ["Overview", "Fundamentals", "News", "Insider", "Earnings"]; return <Shell><PageHero eyebrow="Stock Analysis" title="Research a stock without drowning in data." description="A clean stock page for price, fundamentals, news impact, insider activity, transcript notes and risk lenses." /><section className="mx-auto max-w-7xl px-4 pb-16 laptop:px-8"><div className="mb-5 flex gap-2 overflow-x-auto">{tabs.map((t) => <button key={t} onClick={() => setTab(t)} className={cn("rounded-full px-4 py-2 text-sm font-black", tab === t ? "bg-amber-300 text-black" : "border border-white/10 bg-white/[0.04] text-white/60")}>{t}</button>)}</div><div className="grid grid-cols-1 gap-5 laptop:grid-cols-3"><StatCard label="Selected Stock" value="NVDA" note="Demo analysis" icon={Building2} /><StatCard label="Risk Lens" value="High Growth" note="AI exposure" icon={ShieldCheck} /><StatCard label="Best Use" value="Monitor" note="Watch valuation" icon={Radar} /></div><Card className="mt-5"><h2 className="text-3xl font-black">{tab}</h2><p className="mt-4 max-w-3xl font-semibold leading-7 text-white/55">This section will later connect to Yahoo Finance, SEC EDGAR, Quartr, Trading Economics and paid APIs. For now it is a premium demo surface that shows users the intended experience.</p></Card></section></Shell>; }
export function WatchlistContent() { return <Shell><PageHero eyebrow="Watchlist" title="Track the stocks and stories you care about." description="Save themes, news, insider activity and famous takes in one personal research board." /><ExploreIdeasSection compact /><NewsPreviewSection /></Shell>; }

export function HomePageContent() {
  return <Shell><PageHero eyebrow="Portfolio Stocks" title="Your market command center." description="Start with your own stocks first. Then see diversification, concentration, news impact, insider activity and premium discovery ideas." ><div className="mt-8 flex flex-wrap gap-3"><Link href="/ideas" className="rounded-full bg-amber-300 px-5 py-3 text-sm font-black text-black">Explore trading ideas</Link><Link href="/news" className="rounded-full border border-white/10 bg-white/[0.05] px-5 py-3 text-sm font-black text-white">See news impact</Link></div></PageHero><PortfolioCards /><DiversificationSection /><ExploreIdeasSection compact /><NewsPreviewSection /></Shell>;
}

export function Footer() {
  const columns = [
    { title: "Markets", links: ["US: NYSE & NASDAQ", "India: NSE & BSE", "UK: FTSE", "Canada: TSX", "Australia: ASX", "Japan: NIKKEI"] },
    { title: "Investing Ideas", links: ["Undervalued Companies", "Dividend Powerhouses", "Insider Activity", "Artificial Intelligence", "Nuclear Energy", "Cybersecurity"] },
    { title: "Features & Tools", links: ["Portfolio Tracker", "Stock Analysis", "Stock Screener & Alerts", "Trading Ideas", "News Impact", "Dividend Tracker"] },
    { title: "News & Discovery", links: ["Latest Stock News", "Stocks Affected", "Global Market Insights", "Famous Takes", "Community Narratives", "What’s New"] },
    { title: "Quantifi", links: ["Plans & Pricing", "About Us", "Contact Us", "Help Center", "Learn Stock Investing", "Business & Enterprise"] },
  ];
  return <footer className="border-t border-white/10 bg-[#030305] px-4 py-12 laptop:px-8"><div className="mx-auto grid max-w-7xl grid-cols-1 gap-8 tablet:grid-cols-2 laptop:grid-cols-5">{columns.map((c) => <div key={c.title}><div className="mb-4 text-sm font-black text-white/35">{c.title}</div><div className="space-y-3">{c.links.map((l) => <div key={l} className="text-sm font-bold text-white/75 hover:text-amber-200">{l}</div>)}</div></div>)}</div><div className="mx-auto mt-10 max-w-7xl border-t border-white/10 pt-6 text-xs font-semibold leading-6 text-white/35"><p>Quantifi is an educational market research and analytics platform. It is not financial advice, investment advice, trading advice or a recommendation to buy, sell or hold any security. Market data and demo analytics may be delayed, incomplete or inaccurate.</p><p className="mt-4">© 2026 Quantifi. Terms and Conditions · Privacy Policy · AI Terms · Risk Disclosure</p></div></footer>;
}
