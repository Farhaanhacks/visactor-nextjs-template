# Quantifi v13 UI Fix

This version fixes the light-mode clash by forcing the app shell into a dark premium theme.

## What changed

- Rebuilt Quantifi UI with a premium dark glassmorphism style.
- Made cards and sections interactive using client-side state.
- Added clickable portfolio holdings, news cards, market filters, insider activity filters, famous-take toggles and stock-analysis tabs.
- Updated sidebar branding from the VisActor-style template to Quantifi.
- Removed the broken light-mode look by forcing dark theme at the provider/root level and overriding root CSS colors.
- Added stronger CTAs and visual hooks to make the site feel valuable even before S&P Global / broker integrations.

## Run locally

```bash
npm install
npm run dev
```

or if using pnpm:

```bash
pnpm install
pnpm dev
```

## Vercel

Push this folder to GitHub and import it into Vercel. You can use the Vercel subdomain first and add a custom domain later.
