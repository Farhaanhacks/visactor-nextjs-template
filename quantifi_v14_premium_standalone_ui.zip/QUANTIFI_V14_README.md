# Quantifi v14 Premium Standalone UI

This version removes the old VisActor sidebar/header from the active app layout and replaces it with a full-width premium Quantifi interface.

## Important
Use this entire ZIP/project in Vercel. Do not copy only `ui.tsx` into the old project, because the old layout will keep showing the VisActor sidebar and header.

## Main changes
- Full dark premium theme across the entire page
- No old VisActor left nav/header in the active layout
- New sticky Quantifi top navigation
- Interactive Portfolio cards
- Interactive Explore/Ideas filters
- Interactive News Impact cards
- Interactive Insider Activity filters
- Famous Takes toggles
- Stock Analysis tabs
- Diversification section: industry flow, holding split, geography split
- Professional footer

## Routes
- `/` Portfolio command center
- `/ideas` Investing Ideas
- `/news` News Impact
- `/insider-activity` Insider Activity
- `/explore` Explore Companies / ETFs
- `/famous-takes` Famous Takes
- `/stock-analysis` Stock Analysis
- `/watchlist` Watchlist

## Run
```bash
npm install --legacy-peer-deps
npm run dev
```

Or on Vercel, import the GitHub repo and deploy. Vercel will build automatically.
