"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import type { ComponentType, ReactNode } from "react";
import {
  ArrowRight,
  BellRing,
  BriefcaseBusiness,
  Building2,
  ChartNoAxesCombined,
  CheckCircle2,
  CircleDollarSign,
  Eye,
  Flame,
  Globe2,
  Layers3,
  LineChart,
  Newspaper,
  Radar,
  Search,
  ShieldAlert,
  Sparkles,
  TrendingUp,
  Users,
  Zap,
} from "lucide-react";
import {
  dataSources,
  exploreIdeas,
  famousTakes,
  footerColumns,
  insiderActivity,
  newsItems,
  portfolioHoldings,
} from "@/data/quantifi";
import { cn } from "@/lib/utils";

type IconType = ComponentType<{ size?: number; className?: string }>;

type MarketFilter = "All" | "Global" | "India" | "ETFs" | "AI";

const marketFilters: MarketFilter[] = ["All", "Global", "India", "ETFs", "AI"];

const heroTickerTape = [
  { ticker: "NVDA", move: "+2.4%", tone: "up" },
  { ticker: "AMZN", move: "+0.7%", tone: "up" },
  { ticker: "PLTR", move: "-1.8%", tone: "down" },
  { ticker: "SMH", move: "+1.1%", tone: "up" },
  { ticker: "ORCL", move: "-2.6%", tone: "down" },
  { ticker: "RELIANCE", move: "+0.4%", tone: "up" },
];

function asArray(value: string | string[] | undefined) {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}

export function PageShell({
  eyebrow,
  title,
  description,
  children,
  hero = true,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  children: ReactNode;
  hero?: boolean;
}) {
  return (
    <main className="relative min-h-screen overflow-hidden bg-[#050507] text-white">
      <div className="pointer-events-none absolute inset-0 opacity-80">
        <div className="absolute left-[-12rem] top-[-12rem] h-[32rem] w-[32rem] rounded-full bg-amber-400/20 blur-3xl" />
        <div className="absolute right-[-12rem] top-[10rem] h-[30rem] w-[30rem] rounded-full bg-cyan-400/10 blur-3xl" />
        <div className="absolute bottom-[-15rem] left-[30%] h-[34rem] w-[34rem] rounded-full bg-violet-500/10 blur-3xl" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(255,255,255,0.08),transparent_34%),linear-gradient(180deg,rgba(255,255,255,0.04),transparent_22%)]" />
      </div>

      <section className="relative mx-auto w-full max-w-[1480px] px-5 py-7 tablet:px-8 desktop:px-12">
        {hero ? (
          <div className="mb-8 overflow-hidden rounded-[2rem] border border-white/10 bg-white/[0.04] p-5 shadow-[0_30px_120px_rgba(0,0,0,0.45)] backdrop-blur-xl tablet:p-8">
            <div className="flex flex-col gap-5 laptop:flex-row laptop:items-end laptop:justify-between">
              <div>
                {eyebrow ? (
                  <p className="mb-3 text-sm font-black uppercase tracking-[0.28em] text-amber-300">
                    {eyebrow}
                  </p>
                ) : null}
                <h1 className="max-w-5xl text-4xl font-black tracking-tight text-white tablet:text-6xl">
                  {title}
                </h1>
                {description ? (
                  <p className="mt-4 max-w-3xl text-base leading-7 text-slate-300 tablet:text-lg">
                    {description}
                  </p>
                ) : null}
              </div>

              <div className="flex flex-wrap gap-3">
                <Link
                  href="/ideas"
                  className="inline-flex items-center gap-2 rounded-full bg-amber-300 px-4 py-2 text-sm font-black text-slate-950 shadow-[0_0_30px_rgba(252,211,77,0.35)] transition hover:scale-[1.02] hover:bg-amber-200"
                >
                  Explore ideas <ArrowRight size={16} />
                </Link>
                <Link
                  href="/stock-analysis"
                  className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/10 px-4 py-2 text-sm font-bold text-white transition hover:border-amber-300/50 hover:bg-white/15"
                >
                  Stock Analysis
                </Link>
              </div>
            </div>

            <div className="mt-7 grid gap-3 tablet:grid-cols-2 laptop:grid-cols-6">
              {heroTickerTape.map((item) => (
                <div key={item.ticker} className="rounded-2xl border border-white/10 bg-black/25 p-3">
                  <div className="text-sm font-black text-white">{item.ticker}</div>
                  <div className={cn("mt-1 text-sm font-bold", item.tone === "up" ? "text-emerald-300" : "text-rose-300")}>{item.move}</div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="mb-8">
            {eyebrow ? (
              <p className="mb-2 text-sm font-black uppercase tracking-[0.24em] text-amber-300">
                {eyebrow}
              </p>
            ) : null}
            <h1 className="text-3xl font-black tracking-tight text-white tablet:text-5xl">{title}</h1>
            {description ? <p className="mt-4 max-w-3xl text-base leading-7 text-slate-300 tablet:text-lg">{description}</p> : null}
          </div>
        )}

        {children}
      </section>
    </main>
  );
}

function GlassCard({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        "rounded-[1.6rem] border border-white/10 bg-white/[0.055] shadow-[0_24px_90px_rgba(0,0,0,0.35)] backdrop-blur-xl",
        className,
      )}
    >
      {children}
    </div>
  );
}

function ActionPill({ children, href, active = false, onClick }: { children: ReactNode; href?: string; active?: boolean; onClick?: () => void }) {
  const classes = cn(
    "inline-flex items-center justify-center rounded-full border px-3 py-1.5 text-sm font-bold transition",
    active
      ? "border-amber-300 bg-amber-300 text-slate-950 shadow-[0_0_24px_rgba(252,211,77,0.25)]"
      : "border-white/10 bg-white/[0.06] text-slate-200 hover:border-amber-300/40 hover:bg-white/[0.1]",
  );

  if (href) return <Link href={href} className={classes}>{children}</Link>;
  return <button type="button" className={classes} onClick={onClick}>{children}</button>;
}

function StatCard({ title, value, caption, icon: Icon, accent = "amber" }: { title: string; value: string; caption: string; icon: IconType; accent?: "amber" | "cyan" | "emerald" | "violet" }) {
  const colors = {
    amber: "from-amber-300/20 to-orange-500/5 text-amber-300",
    cyan: "from-cyan-300/20 to-blue-500/5 text-cyan-300",
    emerald: "from-emerald-300/20 to-teal-500/5 text-emerald-300",
    violet: "from-violet-300/20 to-fuchsia-500/5 text-violet-300",
  }[accent];

  return (
    <GlassCard className={cn("group overflow-hidden bg-gradient-to-br p-5 transition hover:-translate-y-1 hover:border-amber-300/40", colors)}>
      <div className="mb-4 flex items-center justify-between">
        <span className="text-sm font-semibold text-slate-300">{title}</span>
        <div className="rounded-2xl border border-white/10 bg-black/25 p-2">
          <Icon size={18} className={cn("transition group-hover:scale-110", colors.split(" ").find((c) => c.startsWith("text-")))} />
        </div>
      </div>
      <div className="text-2xl font-black text-white">{value}</div>
      <p className="mt-2 text-sm text-slate-400">{caption}</p>
    </GlassCard>
  );
}

function PortfolioOverview() {
  const [activeHolding, setActiveHolding] = useState(portfolioHoldings[0].ticker);
  const selectedHolding = portfolioHoldings.find((h) => h.ticker === activeHolding) ?? portfolioHoldings[0];

  return (
    <section className="space-y-6">
      <div className="grid gap-4 tablet:grid-cols-2 laptop:grid-cols-4">
        <StatCard title="Portfolio value" value="US$55.6k" caption="Demo holdings: NVDA + AMZN" icon={BriefcaseBusiness} accent="amber" />
        <StatCard title="Top risk" value="2-stock concentration" caption="Holdings are not diversified yet" icon={ShieldAlert} accent="violet" />
        <StatCard title="News affecting holdings" value="3 stories" caption="AI, cloud and semiconductor themes" icon={Newspaper} accent="cyan" />
        <StatCard title="Insider activity" value="2 alerts" caption="Monitor routine vs unusual activity" icon={BellRing} accent="emerald" />
      </div>

      <div className="grid gap-5 laptop:grid-cols-[1.3fr_0.7fr]">
        <GlassCard className="overflow-hidden p-5">
          <div className="mb-5 flex flex-col gap-4 laptop:flex-row laptop:items-center laptop:justify-between">
            <div>
              <h2 className="text-2xl font-black text-white">Portfolio Stocks</h2>
              <p className="mt-1 text-sm text-slate-400">Click a holding to change the diagnosis panel.</p>
            </div>
            <div className="flex flex-wrap gap-2">
              {portfolioHoldings.map((holding) => (
                <ActionPill key={holding.ticker} active={activeHolding === holding.ticker} onClick={() => setActiveHolding(holding.ticker)}>
                  {holding.ticker}
                </ActionPill>
              ))}
            </div>
          </div>

          <div className="grid gap-4 laptop:grid-cols-2">
            {portfolioHoldings.map((holding) => (
              <button
                type="button"
                key={holding.ticker}
                onClick={() => setActiveHolding(holding.ticker)}
                className={cn(
                  "rounded-[1.5rem] border p-5 text-left transition hover:-translate-y-1 hover:border-amber-300/50",
                  activeHolding === holding.ticker ? "border-amber-300/60 bg-amber-300/[0.08]" : "border-white/10 bg-black/20",
                )}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-3xl font-black text-white">{holding.ticker}</div>
                    <div className="mt-1 text-sm text-slate-400">{holding.company}</div>
                  </div>
                  <span className="rounded-full border border-white/10 bg-white/10 px-3 py-1 text-sm font-black text-white">{holding.weight}%</span>
                </div>
                <div className="mt-6 grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <div className="text-slate-500">Sector</div>
                    <div className="mt-1 font-bold text-white">{holding.sector}</div>
                  </div>
                  <div>
                    <div className="text-slate-500">Industry</div>
                    <div className="mt-1 font-bold text-white">{holding.industry}</div>
                  </div>
                  <div>
                    <div className="text-slate-500">1W</div>
                    <div className="mt-1 font-bold text-emerald-300">+{holding.oneWeek}%</div>
                  </div>
                  <div>
                    <div className="text-slate-500">1Y</div>
                    <div className="mt-1 font-bold text-emerald-300">+{holding.oneYear}%</div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </GlassCard>

        <GlassCard className="relative overflow-hidden p-5">
          <div className="absolute right-[-4rem] top-[-4rem] h-40 w-40 rounded-full bg-amber-300/20 blur-3xl" />
          <div className="relative">
            <div className="mb-4 inline-flex rounded-full bg-amber-300 px-3 py-1 text-xs font-black uppercase tracking-[0.16em] text-slate-950">
              Live diagnosis
            </div>
            <h2 className="text-2xl font-black text-white">{selectedHolding.ticker}: concentration check</h2>
            <p className="mt-3 text-sm leading-6 text-slate-300">
              {selectedHolding.ticker} is {selectedHolding.weight}% of the demo portfolio. The question is not only whether the company is good, but whether this single theme dominates your total risk.
            </p>
            <div className="mt-5 space-y-3 text-sm">
              <div className="rounded-2xl border border-white/10 bg-black/25 p-4 text-slate-300">
                <b className="text-amber-200">Main issue:</b> concentration risk.
              </div>
              <div className="rounded-2xl border border-white/10 bg-black/25 p-4 text-slate-300">
                <b className="text-amber-200">Next check:</b> compare sector, industry, geography, news and insider activity before adding more.
              </div>
            </div>
            <Link href="/stock-analysis" className="mt-5 inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-black text-slate-950 transition hover:bg-amber-200">
              Open Stock Analysis <ArrowRight size={16} />
            </Link>
          </div>
        </GlassCard>
      </div>
    </section>
  );
}

export function DiversificationSection() {
  const [selectedGeo, setSelectedGeo] = useState(portfolioHoldings[1].ticker);
  const selected = portfolioHoldings.find((h) => h.ticker === selectedGeo) ?? portfolioHoldings[1];
  const donutSegments = portfolioHoldings.map((h, idx) => ({
    label: h.ticker,
    value: h.weight,
    color: idx === 0 ? "#80e3cf" : "#5a95e5",
  }));

  return (
    <section className="mt-8 rounded-[2rem] border border-white/10 bg-white/[0.04] p-5 shadow-[0_30px_120px_rgba(0,0,0,0.35)] backdrop-blur-xl tablet:p-8">
      <div className="mb-6 flex flex-col gap-4 laptop:flex-row laptop:items-end laptop:justify-between">
        <div>
          <span className="inline-flex rounded-xl bg-gradient-to-r from-amber-300 to-orange-400 px-3 py-1 text-2xl font-black text-slate-950">Diversification</span>
          <p className="mt-4 max-w-3xl text-slate-400">See whether portfolio risk is spread across sectors, industries, holdings and revenue geographies.</p>
        </div>
        <div className="flex gap-2">
          {portfolioHoldings.map((h) => (
            <ActionPill key={h.ticker} active={selectedGeo === h.ticker} onClick={() => setSelectedGeo(h.ticker)}>{h.ticker}</ActionPill>
          ))}
        </div>
      </div>
      <div className="space-y-8">
        <div>
          <h3 className="mb-4 text-xl font-black text-white">Diversification across Industries</h3>
          <IndustrySankey />
        </div>
        <div className="grid gap-6 laptop:grid-cols-2">
          <div>
            <h3 className="mb-4 text-xl font-black text-white">Diversification across Holdings</h3>
            <DonutCard title="Holdings weight" center="AMZN 53.9%" segments={donutSegments} />
          </div>
          <div>
            <h3 className="mb-4 text-xl font-black text-white">Revenue Diversification by Geography</h3>
            <DonutCard title={`${selected.ticker} revenue geography`} center={selected.ticker} segments={selected.geography} />
          </div>
        </div>
      </div>
    </section>
  );
}

function IndustrySankey() {
  return (
    <div className="overflow-x-auto rounded-[1.5rem] border border-white/10 bg-[#171717] p-4 shadow-inner">
      <svg viewBox="0 0 1100 260" className="h-[260px] min-w-[980px] w-full">
        <defs>
          <linearGradient id="flowGoldV13" x1="0" x2="1">
            <stop offset="0" stopColor="#ffe17b" />
            <stop offset="1" stopColor="#8b7b42" />
          </linearGradient>
          <filter id="shadowV13" x="-10%" y="-10%" width="120%" height="120%">
            <feDropShadow dx="0" dy="8" stdDeviation="6" floodColor="#000" floodOpacity="0.35" />
          </filter>
        </defs>
        <text x="0" y="24" fill="#cbd5e1" fontSize="16" fontWeight="800">Portfolio 100%</text>
        <text x="330" y="24" fill="#94a3b8" fontSize="14" fontWeight="800">Sector</text>
        <text x="675" y="24" fill="#94a3b8" fontSize="14" fontWeight="800">Industry</text>
        <text x="1010" y="24" fill="#94a3b8" fontSize="14" fontWeight="800">Ticker</text>
        <rect x="0" y="84" width="80" height="104" fill="#ffe17b" opacity="0.95" filter="url(#shadowV13)" />
        <path d="M80 84 C220 84 230 60 330 60 L675 60 L1010 60 L1010 108 L675 108 L330 108 C230 108 220 132 80 132 Z" fill="url(#flowGoldV13)" opacity="0.96" />
        <path d="M80 132 C220 132 230 156 330 156 L675 156 L1010 156 L1010 204 L675 204 L330 204 C230 204 220 188 80 188 Z" fill="url(#flowGoldV13)" opacity="0.88" />
        <text x="330" y="126" fill="#dbeafe" fontSize="17" fontWeight="800">Tech 46.1%</text>
        <text x="675" y="126" fill="#dbeafe" fontSize="17" fontWeight="800">Semiconductors 46.1%</text>
        <text x="1018" y="88" fill="#e0f2fe" fontSize="17" fontWeight="900">NVDA</text>
        <text x="330" y="225" fill="#dbeafe" fontSize="17" fontWeight="800">Consumer Discretionary 53.9%</text>
        <text x="675" y="225" fill="#dbeafe" fontSize="17" fontWeight="800">General Merchandise 53.9%</text>
        <text x="1018" y="186" fill="#e0f2fe" fontSize="17" fontWeight="900">AMZN</text>
      </svg>
    </div>
  );
}

function DonutCard({ title, center, segments }: { title: string; center: string; segments: { label?: string; name?: string; value: number; color: string }[] }) {
  let start = 0;
  const gradient = segments
    .map((seg) => {
      const end = start + seg.value;
      const piece = `${seg.color} ${start}% ${end}%`;
      start = end;
      return piece;
    })
    .join(", ");

  return (
    <GlassCard className="p-5">
      <p className="mb-4 text-sm font-bold uppercase tracking-[0.18em] text-slate-500">{title}</p>
      <div className="flex flex-col items-center gap-6 tablet:flex-row">
        <div className="relative grid h-64 w-64 place-items-center rounded-full shadow-[14px_10px_0_rgba(60,89,130,0.45)]" style={{ background: `conic-gradient(${gradient})` }}>
          <div className="grid h-36 w-36 place-items-center rounded-full bg-[#111111] text-center shadow-inner">
            <div>
              <div className="text-lg font-black text-amber-200">{center}</div>
              <div className="mt-2 rounded-full bg-amber-300 px-4 py-1 text-xs font-black text-slate-950">View all</div>
            </div>
          </div>
        </div>
        <div className="grid gap-3">
          {segments.map((seg) => (
            <div key={seg.label ?? seg.name} className="flex items-center gap-3 text-sm">
              <span className="h-3 w-3 rounded-full" style={{ backgroundColor: seg.color }} />
              <span className="text-slate-300">{seg.label ?? seg.name}</span>
              <span className="font-black text-white">{seg.value}%</span>
            </div>
          ))}
        </div>
      </div>
    </GlassCard>
  );
}

export function ExploreIdeasSection({ compact = false }: { compact?: boolean }) {
  const [filter, setFilter] = useState<MarketFilter>("All");
  const filteredIdeas = useMemo(() => {
    if (filter === "All") return exploreIdeas;
    if (filter === "AI") return exploreIdeas.filter((idea) => idea.title.toLowerCase().includes("artificial") || idea.theme.toLowerCase().includes("ai"));
    if (filter === "ETFs") return exploreIdeas.filter((idea) => idea.tickers.some((ticker) => ticker.includes("ARK") || ticker.includes("SMH") || ticker.includes("SOXX"))) || exploreIdeas.slice(0, 3);
    if (filter === "India") return exploreIdeas.filter((idea) => idea.title.toLowerCase().includes("insider")) || exploreIdeas.slice(0, 3);
    return exploreIdeas;
  }, [filter]);

  const shownIdeas = compact ? filteredIdeas.slice(0, 3) : filteredIdeas;

  return (
    <section className={cn("mt-8", compact ? "" : "rounded-[2rem] border border-white/10 bg-white/[0.035] p-5 tablet:p-8")}> 
      <div className="mb-6 flex flex-col gap-4 laptop:flex-row laptop:items-center laptop:justify-between">
        <div>
          <h2 className="text-2xl font-black text-white">Explore More Companies / ETFs</h2>
          <p className="mt-2 text-slate-400">Discovery ideas outside the user’s current portfolio.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {marketFilters.map((item) => (
            <ActionPill key={item} active={filter === item} onClick={() => setFilter(item)}>{item}</ActionPill>
          ))}
        </div>
      </div>
      <div className="grid gap-5 tablet:grid-cols-2 desktop:grid-cols-3">
        {shownIdeas.map((idea) => (
          <IdeaCard key={idea.title} idea={idea} />
        ))}
      </div>
    </section>
  );
}

function IdeaCard({ idea }: { idea: typeof exploreIdeas[number] }) {
  return (
    <Link href="/stock-analysis" className="group block overflow-hidden rounded-[1.6rem] border border-white/10 bg-[#171719] shadow-[0_16px_60px_rgba(0,0,0,0.28)] transition hover:-translate-y-1 hover:border-amber-300/50 hover:shadow-[0_24px_100px_rgba(252,211,77,0.14)]">
      <div className={cn("relative h-40 overflow-hidden bg-gradient-to-br", idea.accent)}>
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.55),transparent_20%),radial-gradient(circle_at_70%_70%,rgba(0,0,0,0.25),transparent_30%)]" />
        <div className="absolute left-5 top-5 rounded-full bg-black/35 px-3 py-1 text-xs font-black text-white backdrop-blur">
          {idea.theme}
        </div>
        <div className="absolute bottom-5 right-5 grid h-16 w-16 place-items-center rounded-full border border-white/40 bg-black/25 text-white backdrop-blur transition group-hover:scale-110">
          <Sparkles size={24} />
        </div>
      </div>
      <div className="p-5">
        <h3 className="text-xl font-black text-white">{idea.title}</h3>
        <p className="mt-2 min-h-12 text-sm leading-6 text-slate-400">{idea.description}</p>
        <div className="mt-5 flex items-center justify-between gap-3">
          <div className="flex -space-x-2">
            {idea.tickers.slice(0, 3).map((ticker) => (
              <span key={ticker} className="grid h-8 w-8 place-items-center rounded-full border border-[#171719] bg-white/10 text-[10px] font-black text-white">{ticker.slice(0, 2)}</span>
            ))}
          </div>
          <div className="text-sm font-black text-white">+{idea.companies} companies {idea.newCount ? <span className="ml-2 rounded-full bg-purple-500 px-2 py-1 text-xs">{idea.newCount} new</span> : null}</div>
        </div>
      </div>
    </Link>
  );
}

export function InvestingIdeasPageContent() {
  return (
    <PageShell title="Investing Ideas" description="Explore market themes, insider activity, ETFs and stocks worth researching. Built to hook users visually before the expensive data stack exists.">
      <div className="mb-6 flex flex-wrap items-center gap-3 border-b border-white/10 pb-4 text-sm font-black text-slate-300">
        <ActionPill active>Investing Ideas</ActionPill>
        <ActionPill href="/explore">Browse All Stocks</ActionPill>
        <ActionPill href="/news">Markets</ActionPill>
        <span className="ml-auto hidden text-white laptop:inline">Have your own idea? Try our <Link href="/stock-analysis" className="underline decoration-amber-300 decoration-2 underline-offset-4">Stock Analysis</Link></span>
      </div>
      <ExploreIdeasSection />
    </PageShell>
  );
}

export function NewsImpactContent() {
  const [selected, setSelected] = useState(newsItems[0]);

  return (
    <PageShell eyebrow="News & Discovery" title="News Impact" description="Show the news users already expect to see, then add what Google News does not: stocks affected, why they are affected, and what to watch next.">
      <div className="grid gap-5 desktop:grid-cols-[0.95fr_1.05fr]">
        <div className="grid gap-4">
          {newsItems.map((item) => (
            <button
              type="button"
              key={item.headline}
              onClick={() => setSelected(item)}
              className={cn(
                "rounded-[1.5rem] border p-5 text-left transition hover:-translate-y-1 hover:border-amber-300/50",
                selected.headline === item.headline ? "border-amber-300/60 bg-amber-300/[0.08]" : "border-white/10 bg-white/[0.04]",
              )}
            >
              <div className="mb-3 flex flex-wrap items-center gap-2">
                <span className="rounded-full bg-white/10 px-3 py-1 text-xs font-bold text-slate-300">{item.source}</span>
                <span className="rounded-full bg-amber-300/10 px-3 py-1 text-xs font-bold text-amber-200">{item.tone}</span>
              </div>
              <h2 className="text-xl font-black text-white">{item.headline}</h2>
              <p className="mt-3 text-sm leading-6 text-slate-400">{item.summary}</p>
            </button>
          ))}
        </div>

        <GlassCard className="sticky top-6 h-fit p-6">
          <div className="mb-4 inline-flex rounded-full bg-amber-300 px-3 py-1 text-xs font-black uppercase tracking-[0.16em] text-slate-950">Stocks affected</div>
          <h2 className="text-2xl font-black text-white">{selected.tone} impact</h2>
          <p className="mt-3 text-sm leading-6 text-slate-300">{selected.why}</p>
          <div className="mt-5 flex flex-wrap gap-2">
            {selected.affected.map((ticker) => (
              <Link key={ticker} href="/stock-analysis" className="rounded-full bg-slate-800 px-3 py-1 text-sm font-black text-slate-100 transition hover:bg-amber-300 hover:text-slate-950">{ticker}</Link>
            ))}
          </div>
          <div className="mt-6 rounded-2xl border border-white/10 bg-black/25 p-4 text-sm leading-6 text-slate-400">
            <b className="text-amber-200">What users get:</b> not just a headline — they see affected stocks, sector exposure, portfolio impact and what to watch next.
          </div>
        </GlassCard>
      </div>
    </PageShell>
  );
}

export function InsiderActivityContent() {
  const [filter, setFilter] = useState("All");
  const filters = ["All", "Positive", "Review", "Neutral", "India"];
  const filtered = insiderActivity.filter((item) => {
    if (filter === "All") return true;
    if (filter === "India") return item.ticker.includes(".NS") || item.signal.toLowerCase().includes("india");
    return item.signal.toLowerCase().includes(filter.toLowerCase()) || item.type.toLowerCase().includes(filter.toLowerCase());
  });

  return (
    <PageShell eyebrow="Market Signals" title="Insider Activity" description="Track insider buying, insider selling, promoter activity, pledge disclosures and unusual activity. This is a research signal, not an automatic buy/sell call.">
      <div className="mb-6 flex flex-wrap gap-2">
        {filters.map((f) => <ActionPill key={f} active={filter === f} onClick={() => setFilter(f)}>{f}</ActionPill>)}
      </div>
      <div className="grid gap-4 laptop:grid-cols-2">
        {filtered.map((item) => (
          <GlassCard key={`${item.ticker}-${item.type}`} className="p-5 transition hover:-translate-y-1 hover:border-amber-300/50">
            <div className="mb-4 flex items-start justify-between gap-4">
              <div>
                <div className="text-3xl font-black text-amber-200">{item.ticker}</div>
                <div className="text-sm text-slate-400">{item.company}</div>
              </div>
              <span className="rounded-full bg-white/10 px-3 py-1 text-xs font-black text-slate-200">{item.signal}</span>
            </div>
            <div className="grid gap-3 text-sm text-slate-300">
              <p><b className="text-white">Type:</b> {item.type}</p>
              <p><b className="text-white">Value:</b> {item.value}</p>
              <p><b className="text-white">Date:</b> {item.date}</p>
              <p className="rounded-2xl bg-black/25 p-4 leading-6"><b className="text-amber-200">Interpretation:</b> {item.interpretation}</p>
            </div>
          </GlassCard>
        ))}
      </div>
    </PageShell>
  );
}

export function FamousTakesContent() {
  const [activeTake, setActiveTake] = useState(famousTakes[0].title);
  const take = famousTakes.find((item) => item.title === activeTake) ?? famousTakes[0];

  return (
    <PageShell eyebrow="Famous Takes" title="Famous Market Takes" description="Summaries of famous investor views translated into simple risk lenses, with the stocks and ETFs most affected.">
      <div className="mb-6 flex flex-wrap gap-2">
        {famousTakes.map((item) => <ActionPill key={item.title} active={activeTake === item.title} onClick={() => setActiveTake(item.title)}>{item.title}</ActionPill>)}
      </div>
      <GlassCard className="p-6">
        <div className="mb-4 flex items-center gap-3">
          <Sparkles className="text-amber-300" size={24} />
          <h2 className="text-3xl font-black text-white">{take.title}</h2>
        </div>
        <p className="text-lg leading-8 text-slate-300">{take.take}</p>
        <div className="mt-6 grid gap-5 laptop:grid-cols-2">
          <div className="rounded-2xl border border-white/10 bg-black/25 p-4">
            <p className="mb-3 font-black text-white">What this take is watching</p>
            <ul className="space-y-2 text-sm text-slate-400">
              {take.watch.map((point) => <li key={point}>• {point}</li>)}
            </ul>
          </div>
          <div className="rounded-2xl border border-white/10 bg-black/25 p-4">
            <p className="mb-3 font-black text-white">Stocks / ETFs affected</p>
            <div className="flex flex-wrap gap-2">
              {take.affected.map((ticker) => <Link href="/stock-analysis" key={ticker} className="rounded-full bg-slate-800 px-3 py-1 text-sm font-black text-white transition hover:bg-amber-300 hover:text-slate-950">{ticker}</Link>)}
            </div>
            <p className="mt-4 text-sm leading-6 text-slate-400"><b className="text-amber-200">Takeaway:</b> {take.takeaway}</p>
          </div>
        </div>
      </GlassCard>
    </PageShell>
  );
}

export function StockAnalysisContent() {
  const [tab, setTab] = useState("Overview");
  const tabs = ["Overview", "News", "Insider", "Filings", "Data Stack"];

  return (
    <PageShell eyebrow="Company Research" title="Stock Analysis" description="A clear page for company fundamentals, news, insider activity, transcripts, filings and portfolio impact.">
      <div className="mb-6 flex flex-wrap gap-2">
        {tabs.map((t) => <ActionPill key={t} active={tab === t} onClick={() => setTab(t)}>{t}</ActionPill>)}
      </div>
      <div className="grid gap-5 desktop:grid-cols-[0.9fr_1.1fr]">
        <GlassCard className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-3xl font-black text-white">NVDA</h2>
              <p className="mt-1 text-slate-400">NVIDIA Stock Analysis</p>
            </div>
            <span className="rounded-full bg-emerald-400/10 px-3 py-1 text-sm font-black text-emerald-300">AI leader</span>
          </div>
          <div className="mt-5 h-48 rounded-2xl border border-white/10 bg-[linear-gradient(135deg,rgba(252,211,77,.14),rgba(34,211,238,.12)),radial-gradient(circle_at_60%_40%,rgba(255,255,255,.18),transparent_22%)] p-5">
            <div className="text-sm font-bold text-slate-400">Interactive chart placeholder</div>
            <div className="mt-12 h-2 rounded-full bg-gradient-to-r from-emerald-300 via-amber-300 to-sky-300" />
            <div className="mt-5 grid grid-cols-4 gap-2 text-xs font-bold text-slate-300">
              <span>1D</span><span>1M</span><span>1Y</span><span>5Y</span>
            </div>
          </div>
        </GlassCard>

        <GlassCard className="p-5">
          <h3 className="mb-4 text-xl font-black text-white">{tab}</h3>
          {tab === "Overview" ? (
            <div className="grid gap-3 text-sm">
              <div className="rounded-2xl bg-black/25 p-4"><b className="text-amber-200">Business type:</b> Semiconductors / AI infrastructure</div>
              <div className="rounded-2xl bg-black/25 p-4"><b className="text-amber-200">Best use:</b> High-conviction growth exposure, not a low-risk income hold</div>
              <div className="rounded-2xl bg-black/25 p-4"><b className="text-amber-200">Risk lens:</b> AI capex cycle, customer concentration, valuation multiple compression</div>
            </div>
          ) : tab === "News" ? (
            <NewsMiniList />
          ) : tab === "Insider" ? (
            <div className="space-y-3">{insiderActivity.slice(0, 2).map((x) => <div key={x.ticker} className="rounded-2xl bg-black/25 p-4 text-sm text-slate-300"><b className="text-amber-200">{x.ticker}</b> — {x.type}: {x.interpretation}</div>)}</div>
          ) : tab === "Filings" ? (
            <div className="space-y-3 text-sm text-slate-300"><div className="rounded-2xl bg-black/25 p-4">SEC EDGAR filing summaries and XBRL facts will power this layer.</div><div className="rounded-2xl bg-black/25 p-4">Quartr transcripts and decks can later add management commentary.</div></div>
          ) : (
            <DataSourceGrid compact />
          )}
        </GlassCard>
      </div>
    </PageShell>
  );
}

function NewsMiniList() {
  return (
    <div className="space-y-3">
      {newsItems.map((item) => (
        <div key={item.headline} className="rounded-2xl bg-black/25 p-4 text-sm text-slate-300">
          <div className="font-black text-white">{item.headline}</div>
          <div className="mt-2 flex flex-wrap gap-2">{item.affected.slice(0, 5).map((x) => <span className="rounded-full bg-white/10 px-2 py-1 text-xs font-bold" key={x}>{x}</span>)}</div>
        </div>
      ))}
    </div>
  );
}

function DataSourceGrid({ compact = false }: { compact?: boolean }) {
  return (
    <div className={cn("grid gap-4", compact ? "" : "laptop:grid-cols-2 desktop:grid-cols-3")}> 
      {dataSources.map((source) => (
        <GlassCard key={source.name} className="p-4">
          <div className="font-black text-white">{source.name}</div>
          <div className="mt-2 text-sm leading-6 text-slate-400">{source.use}</div>
          <div className="mt-3 inline-flex rounded-full bg-amber-300/10 px-3 py-1 text-xs font-black uppercase tracking-[0.12em] text-amber-200">{source.role}</div>
        </GlassCard>
      ))}
    </div>
  );
}

export function DataSourceContent() {
  return (
    <section className="mt-8 rounded-[2rem] border border-white/10 bg-white/[0.035] p-6">
      <h2 className="text-2xl font-black text-white">Data Source Plan</h2>
      <p className="mt-2 text-slate-400">The UI is designed to feel premium now. Data quality can upgrade one layer at a time.</p>
      <div className="mt-5">
        <DataSourceGrid />
      </div>
    </section>
  );
}

export function HomePageContent() {
  return (
    <PageShell eyebrow="Quantifi Beta" title="Your market intelligence command center" description="A premium web dashboard for portfolio stocks, diversification, trading ideas, news impact, insider activity and famous market takes — built to feel valuable before the expensive S&P/broker layers arrive.">
      <PortfolioOverview />
      <DiversificationSection />
      <ExploreIdeasSection compact />
      <NewsImpactPreview />
      <DataSourceContent />
    </PageShell>
  );
}

function NewsImpactPreview() {
  return (
    <section className="mt-8 grid gap-5 desktop:grid-cols-[0.8fr_1.2fr]">
      <GlassCard className="p-6">
        <div className="mb-3 flex items-center gap-2 text-amber-300"><Zap size={20} /><span className="font-black">Daily hook</span></div>
        <h2 className="text-2xl font-black text-white">What moved today?</h2>
        <p className="mt-3 text-sm leading-6 text-slate-400">This is the section that can hook Reel traffic: news, stocks affected, insider activity and famous takes in one screen.</p>
        <div className="mt-5 flex flex-wrap gap-2">
          <ActionPill href="/news">Open News Impact</ActionPill>
          <ActionPill href="/insider-activity">Open Insider Activity</ActionPill>
        </div>
      </GlassCard>
      <div className="grid gap-4 laptop:grid-cols-3">
        {newsItems.map((item) => (
          <Link href="/news" key={item.headline} className="rounded-[1.5rem] border border-white/10 bg-white/[0.04] p-5 transition hover:-translate-y-1 hover:border-amber-300/50">
            <div className="mb-3 text-xs font-black uppercase tracking-[0.16em] text-amber-300">{item.tone}</div>
            <div className="text-lg font-black text-white">{item.headline}</div>
            <div className="mt-4 flex flex-wrap gap-2">{item.affected.slice(0, 4).map((x) => <span className="rounded-full bg-white/10 px-2 py-1 text-xs font-bold text-slate-200" key={x}>{x}</span>)}</div>
          </Link>
        ))}
      </div>
    </section>
  );
}

export function WatchlistContent() {
  return (
    <PageShell eyebrow="Saved Research" title="Watchlist" description="Save companies, ETFs, themes, famous takes and insider-activity ideas for later research.">
      <ExploreIdeasSection compact />
      <NewsImpactPreview />
    </PageShell>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-white/10 bg-[#050507] px-5 py-10 text-white tablet:px-8 desktop:px-12">
      <div className="mx-auto grid max-w-[1480px] gap-8 tablet:grid-cols-2 laptop:grid-cols-5">
        {footerColumns.map((column) => (
          <div key={column.title}>
            <h3 className="mb-4 text-sm font-black text-slate-500">{column.title}</h3>
            <ul className="space-y-3">
              {column.links.map((link) => (
                <li key={link}><Link className="text-sm font-bold text-slate-100 hover:text-amber-200" href="#">{link}</Link></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="mx-auto mt-10 grid max-w-[1480px] gap-6 border-t border-white/10 pt-6 text-sm leading-6 text-slate-500 laptop:grid-cols-[1.5fr_1fr]">
        <p>Quantifi is an educational market research and analytics platform. Information shown is for general informational purposes only and should not be treated as financial advice, investment advice, trading advice, or a recommendation to buy, sell or hold any security. Market data, news, financial information, insider activity and portfolio insights may be delayed, incomplete or inaccurate. Users should independently verify all information and consult a qualified financial adviser before making investment decisions.</p>
        <div>
          <p>© 2026 Quantifi. All rights reserved.</p>
          <div className="mt-3 flex flex-wrap gap-4">
            <Link href="#">Terms and Conditions</Link>
            <Link href="#">Privacy Policy</Link>
            <Link href="#">AI Terms</Link>
            <Link href="#">Risk Disclosure</Link>
          </div>
        </div>
      </div>
    </footer>
  );
}

export const navIconMap = {
  portfolio: BriefcaseBusiness,
  ideas: Sparkles,
  news: Newspaper,
  insider: Users,
  explore: Search,
  famous: Eye,
  analysis: ChartNoAxesCombined,
  watchlist: CircleDollarSign,
  markets: Building2,
  trading: TrendingUp,
  layers: Layers3,
  radar: Radar,
  chart: LineChart,
  flame: Flame,
  check: CheckCircle2,
  globe: Globe2,
};
