import type { Metadata } from "next";
import { Gabarito } from "next/font/google";
import { SideNav } from "@/components/nav";
import { Footer } from "@/components/quantifi/ui";
import { siteConfig } from "@/config/site";
import { cn } from "@/lib/utils";
import "@/style/globals.css";
import { Providers } from "./providers";

const gabarito = Gabarito({ subsets: ["latin"], variable: "--font-gabarito" });

export const metadata: Metadata = {
  title: siteConfig.title,
  description: siteConfig.description,
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className="dark" suppressHydrationWarning>
      <body className={cn("min-h-screen bg-[#050507] font-sans text-white antialiased", gabarito.variable)}>
        <Providers>
          <div className="flex min-h-[100dvh] bg-[#050507] text-white">
            <SideNav />
            <div className="min-w-0 flex-grow overflow-auto bg-[#050507]">
              {children}
              <Footer />
            </div>
          </div>
        </Providers>
      </body>
    </html>
  );
}
