# Quantifi Next.js Market Intelligence Template

A mobile-first, Vercel-ready investing website prototype built from the VisActor Next.js template and redesigned for Quantifi.

## What is included

- Portfolio Stocks homepage
- Diversification module: industry flow, holdings donut, geography donut
- Trading Ideas / Investing Ideas cards
- Explore Companies / ETFs
- News Impact with stocks affected
- Insider Activity
- Famous Takes, including Michael Burry AI bubble lens and vendor-financing loop explanation
- Stock Analysis page
- Watchlist page
- Professional multi-column footer with risk disclaimer
- Data-source plan: Yahoo Finance, SEC EDGAR, Quartr, Trading Economics, Koyfin, TIKR, Macrotrends

## Run locally

```bash
pnpm install
pnpm dev
```

Then open http://localhost:3000

## Deploy on Vercel

1. Push this folder to GitHub.
2. Import the repo into Vercel.
3. Deploy with the default Vercel URL first.
4. Add your custom domain later from Vercel Project Settings → Domains.

## Notes

This is a prototype. The visible data is demo/static data. Production data should be connected through backend API routes and cached through Supabase/Vercel storage layers.
