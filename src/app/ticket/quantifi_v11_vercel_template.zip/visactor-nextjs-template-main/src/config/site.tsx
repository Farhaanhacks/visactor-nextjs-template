import {
  BellRing,
  BriefcaseBusiness,
  ChartNoAxesCombined,
  Eye,
  Newspaper,
  Search,
  Sparkles,
  type LucideIcon,
  Users,
} from "lucide-react";

export type SiteConfig = typeof siteConfig;
export type Navigation = {
  icon: LucideIcon;
  name: string;
  href: string;
};

export const siteConfig = {
  title: "Quantifi",
  description: "AI-first market intelligence for portfolio stocks, trading ideas, news impact, insider activity and famous market takes.",
};

export const navigations: Navigation[] = [
  {
    icon: BriefcaseBusiness,
    name: "Portfolio Stocks",
    href: "/",
  },
  {
    icon: Sparkles,
    name: "Trading Ideas",
    href: "/ideas",
  },
  {
    icon: Newspaper,
    name: "News Impact",
    href: "/news",
  },
  {
    icon: Users,
    name: "Insider Activity",
    href: "/insider-activity",
  },
  {
    icon: Search,
    name: "Explore",
    href: "/explore",
  },
  {
    icon: Eye,
    name: "Famous Takes",
    href: "/famous-takes",
  },
  {
    icon: ChartNoAxesCombined,
    name: "Stock Analysis",
    href: "/stock-analysis",
  },
  {
    icon: BellRing,
    name: "Watchlist",
    href: "/watchlist",
  },
];
