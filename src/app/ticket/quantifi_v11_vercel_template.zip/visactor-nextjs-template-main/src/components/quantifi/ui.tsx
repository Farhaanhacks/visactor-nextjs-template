import Link from "next/link";
import {
  ArrowRight,
  BellRing,
  BriefcaseBusiness,
  Building2,
  ChartNoAxesCombined,
  CircleDollarSign,
  Eye,
  Newspaper,
  Search,
  ShieldAlert,
  Sparkles,
  TrendingUp,
  Users,
} from "lucide-react";
import { dataSources, exploreIdeas, famousTakes, footerColumns, insiderActivity, newsItems, portfolioHoldings } from "@/data/quantifi";
import { cn } from "@/lib/utils";

export function PageShell({
  eyebrow,
  title,
  description,
  children,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <main className="mx-auto w-full max-w-[1480px] px-5 py-7 tablet:px-8 desktop:px-12">
      <div className="mb-8 flex flex-col gap-4 laptop:flex-row laptop:items-end laptop:justify-between">
        <div>
          {eyebrow ? <p className="mb-2 text-sm font-semibold uppercase tracking-[0.24em] text-amber-300/90">{eyebrow}</p> : null}
          <h1 className="text-3xl font-bold tracking-tight text-white tablet:text-5xl">{title}</h1>
          {description ? <p className="mt-4 max-w-3xl text-base leading-7 text-slate-400 tablet:text-lg">{description}</p> : null}
        </div>
        <Link href="/stock-analysis" className="inline-flex items-center gap-2 rounded-full border border-amber-300/30 bg-amber-300/10 px-4 py-2 text-sm font-semibold text-amber-100 hover:bg-amber-300/20">
          Try Stock Analysis <ArrowRight size={16} />
        </Link>
      </div>
      {children}
    </main>
  );
}

export function StatCard({ title, value, caption, icon: Icon }: { title: string; value: string; caption: string; icon: React.ComponentType<{ size?: number; className?: string }> }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.035] p-5 shadow-[0_24px_80px_rgba(0,0,0,0.25)]">
      <div className="mb-4 flex items-center justify-between">
        <span className="text-sm text-slate-400">{title}</span>
        <Icon size={18} className="text-amber-300" />
      </div>
      <div className="text-2xl font-bold text-white">{value}</div>
      <p className="mt-2 text-sm text-slate-500">{caption}</p>
    </div>
  );
}

export function PortfolioOverview() {
  return (
    <section className="space-y-6">
      <div className="grid gap-4 tablet:grid-cols-2 laptop:grid-cols-4">
        <StatCard title="Portfolio value" value="US$55.6k" caption="Demo holdings: NVDA + AMZN" icon={BriefcaseBusiness} />
        <StatCard title="Top risk" value="2-stock concentration" caption="Holdings are not diversified yet" icon={ShieldAlert} />
        <StatCard title="News affecting holdings" value="3 stories" caption="AI, cloud and semiconductor themes" icon={Newspaper} />
        <StatCard title="Insider activity" value="2 alerts" caption="Monitor routine vs unusual activity" icon={BellRing} />
      </div>

      <div className="grid gap-5 laptop:grid-cols-[1.2fr_0.8fr]">
        <div className="rounded-2xl border border-white/10 bg-[#111214] p-5">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold text-white">Portfolio Stocks</h2>
              <p className="text-sm text-slate-400">Homepage lands on the user’s own stocks first.</p>
            </div>
            <span className="rounded-full bg-emerald-400/10 px-3 py-1 text-xs font-semibold text-emerald-300">Personalized</span>
          </div>
          <div className="overflow-hidden rounded-xl border border-white/10">
            <table className="w-full min-w-[680px] text-left text-sm">
              <thead className="bg-white/[0.04] text-slate-400">
                <tr>
                  <th className="px-4 py-3">Ticker</th>
                  <th className="px-4 py-3">Company</th>
                  <th className="px-4 py-3">Sector</th>
                  <th className="px-4 py-3">Weight</th>
                  <th className="px-4 py-3">Value</th>
                  <th className="px-4 py-3">1W</th>
                  <th className="px-4 py-3">1Y</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/10">
                {portfolioHoldings.map((holding) => (
                  <tr key={holding.ticker} className="text-slate-200">
                    <td className="px-4 py-4 font-bold text-amber-200">{holding.ticker}</td>
                    <td className="px-4 py-4">{holding.company}</td>
                    <td className="px-4 py-4 text-slate-400">{holding.sector}</td>
                    <td className="px-4 py-4">{holding.weight}%</td>
                    <td className="px-4 py-4">{holding.value}</td>
                    <td className="px-4 py-4 text-emerald-300">{holding.oneWeek}%</td>
                    <td className="px-4 py-4 text-emerald-300">{holding.oneYear}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div className="rounded-2xl border border-amber-300/20 bg-gradient-to-br from-amber-300/10 to-transparent p-5">
          <h2 className="text-xl font-semibold text-white">Portfolio Diagnosis</h2>
          <p className="mt-3 text-sm leading-6 text-slate-300">This portfolio is highly concentrated. It owns only two stocks and both are exposed to major market narratives: AI infrastructure and US consumer/cloud spending.</p>
          <div className="mt-5 space-y-3 text-sm">
            <div className="rounded-xl bg-black/25 p-3 text-slate-300"><b className="text-amber-200">Main issue:</b> diversification risk, not necessarily company quality.</div>
            <div className="rounded-xl bg-black/25 p-3 text-slate-300"><b className="text-amber-200">Next check:</b> add sector, industry and geography diversification before increasing size.</div>
          </div>
        </div>
      </div>
    </section>
  );
}

export function DiversificationSection() {
  const donutSegments = portfolioHoldings.map((h, idx) => ({
    label: h.ticker,
    value: h.weight,
    color: idx === 0 ? "#7dd3c7" : "#60a5fa",
  }));
  return (
    <section className="mt-8 rounded-3xl border border-white/10 bg-[#151515] p-5 tablet:p-8">
      <div className="mb-6">
        <span className="inline-flex bg-amber-700/70 px-2 py-1 text-3xl font-bold text-white">Diversification</span>
        <p className="mt-4 max-w-3xl text-slate-400">See whether portfolio risk is spread across sectors, industries, holdings and revenue geographies.</p>
      </div>
      <div className="space-y-8">
        <div>
          <h3 className="mb-4 text-xl font-semibold text-white">Diversification across Industries</h3>
          <IndustrySankey />
        </div>
        <div className="grid gap-6 laptop:grid-cols-2">
          <div>
            <h3 className="mb-4 text-xl font-semibold text-white">Diversification across Holdings</h3>
            <DonutCard title="Holdings weight" center="AMZN 53.9%" segments={donutSegments} />
          </div>
          <div>
            <h3 className="mb-4 text-xl font-semibold text-white">Revenue Diversification by Geography</h3>
            <DonutCard title="AMZN revenue geography" center="Not Reported" segments={portfolioHoldings[1].geography} />
          </div>
        </div>
      </div>
    </section>
  );
}

function IndustrySankey() {
  return (
    <div className="overflow-x-auto rounded-2xl bg-[#202020] p-4">
      <svg viewBox="0 0 1100 260" className="h-[260px] min-w-[980px] w-full">
        <defs>
          <linearGradient id="flowGold" x1="0" x2="1">
            <stop offset="0" stopColor="#f8d56b" />
            <stop offset="1" stopColor="#8b7b42" />
          </linearGradient>
        </defs>
        <text x="0" y="24" fill="#cbd5e1" fontSize="16" fontWeight="700">Portfolio 100%</text>
        <text x="330" y="24" fill="#94a3b8" fontSize="14" fontWeight="700">Sector</text>
        <text x="675" y="24" fill="#94a3b8" fontSize="14" fontWeight="700">Industry</text>
        <text x="1010" y="24" fill="#94a3b8" fontSize="14" fontWeight="700">Ticker</text>
        <rect x="0" y="84" width="80" height="104" fill="#f8d56b" opacity="0.95" />
        <path d="M80 84 C220 84 230 60 330 60 L675 60 L1010 60 L1010 108 L675 108 L330 108 C230 108 220 132 80 132 Z" fill="url(#flowGold)" opacity="0.96" />
        <path d="M80 132 C220 132 230 156 330 156 L675 156 L1010 156 L1010 204 L675 204 L330 204 C230 204 220 188 80 188 Z" fill="url(#flowGold)" opacity="0.88" />
        <text x="330" y="126" fill="#cbd5e1" fontSize="17" fontWeight="700">Tech 46.1%</text>
        <text x="675" y="126" fill="#cbd5e1" fontSize="17" fontWeight="700">Semiconductors 46.1%</text>
        <text x="1018" y="88" fill="#dbeafe" fontSize="17" fontWeight="700">NVDA</text>
        <text x="330" y="225" fill="#cbd5e1" fontSize="17" fontWeight="700">Consumer Discretionary 53.9%</text>
        <text x="675" y="225" fill="#cbd5e1" fontSize="17" fontWeight="700">General Merchandise 53.9%</text>
        <text x="1018" y="186" fill="#dbeafe" fontSize="17" fontWeight="700">AMZN</text>
      </svg>
    </div>
  );
}

function DonutCard({ title, center, segments }: { title: string; center: string; segments: { label?: string; name?: string; value: number; color: string }[] }) {
  let start = 0;
  const gradient = segments
    .map((seg) => {
      const end = start + seg.value;
      const piece = `${seg.color} ${start}% ${end}%`;
      start = end;
      return piece;
    })
    .join(", ");
  return (
    <div className="rounded-2xl border border-white/10 bg-[#202020] p-5">
      <p className="mb-4 text-sm text-slate-400">{title}</p>
      <div className="flex flex-col items-center gap-6 tablet:flex-row">
        <div className="relative grid h-64 w-64 place-items-center rounded-full shadow-[14px_10px_0_rgba(60,89,130,0.45)]" style={{ background: `conic-gradient(${gradient})` }}>
          <div className="grid h-36 w-36 place-items-center rounded-full bg-[#202020] text-center">
            <div>
              <div className="text-lg font-bold text-amber-200">{center}</div>
              <div className="mt-1 text-xs text-slate-400">View all</div>
            </div>
          </div>
        </div>
        <div className="grid gap-3">
          {segments.map((seg) => (
            <div key={seg.label ?? seg.name} className="flex items-center gap-3 text-sm">
              <span className="h-3 w-3 rounded-full" style={{ backgroundColor: seg.color }} />
              <span className="text-slate-300">{seg.label ?? seg.name}</span>
              <span className="font-semibold text-white">{seg.value}%</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function ExploreIdeasSection({ compact = false }: { compact?: boolean }) {
  return (
    <section className={cn("mt-8", compact ? "" : "rounded-3xl border border-white/10 bg-white/[0.025] p-5 tablet:p-8")}>
      <div className="mb-6 flex flex-col gap-3 laptop:flex-row laptop:items-center laptop:justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Explore More Companies / ETFs</h2>
          <p className="mt-2 text-slate-400">Discovery ideas outside the user’s current portfolio.</p>
        </div>
        <div className="flex gap-2 text-sm">
          <span className="rounded-full bg-white/10 px-3 py-1 text-slate-300">Global</span>
          <span className="rounded-full bg-white/10 px-3 py-1 text-slate-300">India</span>
          <span className="rounded-full bg-white/10 px-3 py-1 text-slate-300">ETFs</span>
        </div>
      </div>
      <div className="grid gap-5 tablet:grid-cols-2 desktop:grid-cols-3">
        {exploreIdeas.map((idea) => (
          <IdeaCard key={idea.title} idea={idea} />
        ))}
      </div>
    </section>
  );
}

function IdeaCard({ idea }: { idea: typeof exploreIdeas[number] }) {
  return (
    <div className="overflow-hidden rounded-2xl border border-white/10 bg-[#1c1c1d] shadow-[0_16px_60px_rgba(0,0,0,0.25)]">
      <div className={cn("h-36 bg-gradient-to-br", idea.accent)}>
        <div className="flex h-full items-end justify-between p-5">
          <span className="rounded-full bg-black/30 px-3 py-1 text-xs font-semibold text-white">{idea.theme}</span>
          <div className="h-16 w-16 rounded-full border border-white/40 bg-black/25" />
        </div>
      </div>
      <div className="p-5">
        <h3 className="text-xl font-bold text-white">{idea.title}</h3>
        <p className="mt-2 min-h-12 text-sm leading-6 text-slate-400">{idea.description}</p>
        <div className="mt-5 flex items-center justify-between">
          <div className="flex -space-x-2">
            {idea.tickers.slice(0, 3).map((ticker) => (
              <span key={ticker} className="grid h-8 w-8 place-items-center rounded-full border border-[#1c1c1d] bg-white/10 text-[10px] font-bold text-white">{ticker.slice(0, 2)}</span>
            ))}
          </div>
          <div className="text-sm font-bold text-white">+{idea.companies} companies {idea.newCount ? <span className="ml-2 rounded-full bg-purple-500 px-2 py-1 text-xs">{idea.newCount} new</span> : null}</div>
        </div>
      </div>
    </div>
  );
}

export function InvestingIdeasPageContent() {
  return (
    <PageShell title="Investing Ideas" description="Explore investing ideas for any market cycle. From fundamentals and industry themes to insider activity and market narratives, find stocks worth researching.">
      <div className="mb-6 flex flex-wrap items-center gap-4 border-b border-white/10 pb-4 text-sm font-semibold text-slate-300">
        <span className="border-b-2 border-amber-300 pb-3 text-white">Investing Ideas</span>
        <span>Browse All Stocks</span>
        <span>Markets</span>
        <span className="ml-auto hidden text-white laptop:inline">Have your own idea? Try our <Link href="/stock-analysis" className="underline decoration-amber-300">Stock Analysis</Link></span>
      </div>
      <ExploreIdeasSection compact />
    </PageShell>
  );
}

export function NewsImpactContent() {
  return (
    <PageShell eyebrow="News & Discovery" title="News Impact" description="Show the news users already expect to see, then add what Google News does not: stocks affected, why they are affected, and what to watch next.">
      <div className="grid gap-5">
        {newsItems.map((item) => (
          <article key={item.headline} className="rounded-2xl border border-white/10 bg-[#151515] p-5">
            <div className="mb-3 flex flex-wrap items-center gap-2">
              <span className="rounded-full bg-white/10 px-3 py-1 text-xs font-semibold text-slate-300">{item.source}</span>
              <span className="rounded-full bg-amber-300/10 px-3 py-1 text-xs font-semibold text-amber-200">{item.tone}</span>
            </div>
            <h2 className="text-xl font-bold text-white">{item.headline}</h2>
            <p className="mt-3 text-slate-400">{item.summary}</p>
            <div className="mt-5 rounded-xl bg-white/[0.035] p-4">
              <p className="text-sm font-semibold text-white">Stocks affected</p>
              <div className="mt-3 flex flex-wrap gap-2">
                {item.affected.map((ticker) => (
                  <span key={ticker} className="rounded-full bg-slate-800 px-3 py-1 text-sm font-semibold text-slate-100">{ticker}</span>
                ))}
              </div>
              <p className="mt-4 text-sm leading-6 text-slate-400"><b className="text-amber-200">Why:</b> {item.why}</p>
            </div>
          </article>
        ))}
      </div>
    </PageShell>
  );
}

export function InsiderActivityContent() {
  return (
    <PageShell eyebrow="Market Signals" title="Insider Activity" description="Track insider buying, insider selling, promoter activity, pledge disclosures and unusual activity. This is a research signal, not an automatic buy/sell call.">
      <div className="grid gap-4 laptop:grid-cols-2">
        {insiderActivity.map((item) => (
          <div key={`${item.ticker}-${item.type}`} className="rounded-2xl border border-white/10 bg-[#151515] p-5">
            <div className="mb-4 flex items-start justify-between gap-4">
              <div>
                <div className="text-2xl font-bold text-amber-200">{item.ticker}</div>
                <div className="text-sm text-slate-400">{item.company}</div>
              </div>
              <span className="rounded-full bg-white/10 px-3 py-1 text-xs font-semibold text-slate-200">{item.signal}</span>
            </div>
            <div className="grid gap-3 text-sm text-slate-300">
              <p><b className="text-white">Type:</b> {item.type}</p>
              <p><b className="text-white">Value:</b> {item.value}</p>
              <p><b className="text-white">Date:</b> {item.date}</p>
              <p className="rounded-xl bg-white/[0.035] p-3 leading-6"><b className="text-amber-200">Interpretation:</b> {item.interpretation}</p>
            </div>
          </div>
        ))}
      </div>
    </PageShell>
  );
}

export function FamousTakesContent() {
  return (
    <PageShell eyebrow="Famous Takes" title="Famous Market Takes" description="Summaries of famous investor views translated into simple risk lenses, with the stocks and ETFs most affected.">
      <div className="grid gap-5">
        {famousTakes.map((take) => (
          <article key={take.title} className="rounded-2xl border border-white/10 bg-[#151515] p-6">
            <div className="mb-4 flex items-center gap-3">
              <Sparkles className="text-amber-300" size={22} />
              <h2 className="text-2xl font-bold text-white">{take.title}</h2>
            </div>
            <p className="text-lg leading-7 text-slate-300">{take.take}</p>
            <div className="mt-6 grid gap-5 laptop:grid-cols-2">
              <div className="rounded-xl bg-white/[0.035] p-4">
                <p className="mb-3 font-semibold text-white">What this take is watching</p>
                <ul className="space-y-2 text-sm text-slate-400">
                  {take.watch.map((point) => <li key={point}>• {point}</li>)}
                </ul>
              </div>
              <div className="rounded-xl bg-white/[0.035] p-4">
                <p className="mb-3 font-semibold text-white">Stocks / ETFs affected</p>
                <div className="flex flex-wrap gap-2">
                  {take.affected.map((ticker) => <span key={ticker} className="rounded-full bg-slate-800 px-3 py-1 text-sm font-semibold text-white">{ticker}</span>)}
                </div>
                <p className="mt-4 text-sm leading-6 text-slate-400"><b className="text-amber-200">Takeaway:</b> {take.takeaway}</p>
              </div>
            </div>
          </article>
        ))}
      </div>
    </PageShell>
  );
}

export function StockAnalysisContent() {
  return (
    <PageShell eyebrow="Company Research" title="Stock Analysis" description="A clear page for company fundamentals, news, insider activity, transcripts, filings and portfolio impact.">
      <div className="grid gap-5 desktop:grid-cols-[0.9fr_1.1fr]">
        <div className="rounded-2xl border border-white/10 bg-[#151515] p-5">
          <h2 className="text-2xl font-bold text-white">NVDA Stock Analysis</h2>
          <p className="mt-2 text-slate-400">AI infrastructure leader with high growth expectations and high valuation sensitivity.</p>
          <div className="mt-5 grid gap-3 text-sm">
            <div className="rounded-xl bg-white/[0.035] p-4"><b className="text-amber-200">Business type:</b> Semiconductors / AI infrastructure</div>
            <div className="rounded-xl bg-white/[0.035] p-4"><b className="text-amber-200">Best use:</b> High-conviction growth exposure, not a low-risk income hold</div>
            <div className="rounded-xl bg-white/[0.035] p-4"><b className="text-amber-200">Risk lens:</b> AI capex cycle, customer concentration, valuation multiple compression</div>
          </div>
        </div>
        <div className="rounded-2xl border border-white/10 bg-[#151515] p-5">
          <h3 className="mb-4 text-xl font-semibold text-white">Data stack for this page</h3>
          <div className="grid gap-3">
            {dataSources.slice(0, 4).map((source) => (
              <div key={source.name} className="rounded-xl bg-white/[0.035] p-4">
                <div className="font-semibold text-white">{source.name}</div>
                <div className="mt-1 text-sm text-slate-400">{source.use}</div>
                <div className="mt-2 text-xs uppercase tracking-[0.18em] text-amber-300">{source.role}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </PageShell>
  );
}

export function DataSourceContent() {
  return (
    <section className="mt-8 rounded-3xl border border-white/10 bg-[#151515] p-6">
      <h2 className="text-2xl font-bold text-white">Data Source Plan</h2>
      <p className="mt-2 text-slate-400">Use free and accessible sources first, then upgrade one layer at a time.</p>
      <div className="mt-5 grid gap-4 laptop:grid-cols-2 desktop:grid-cols-3">
        {dataSources.map((source) => (
          <div key={source.name} className="rounded-2xl border border-white/10 bg-white/[0.025] p-4">
            <div className="font-semibold text-white">{source.name}</div>
            <div className="mt-2 text-sm leading-6 text-slate-400">{source.use}</div>
            <div className="mt-3 rounded-full bg-amber-300/10 px-3 py-1 text-xs font-semibold text-amber-200">{source.role}</div>
          </div>
        ))}
      </div>
    </section>
  );
}

export function HomePageContent() {
  return (
    <PageShell eyebrow="Quantifi Beta" title="Portfolio Stocks" description="The homepage starts with the user’s own stocks, then opens discovery through trading ideas, news impact, insider activity and famous takes.">
      <PortfolioOverview />
      <DiversificationSection />
      <ExploreIdeasSection />
      <DataSourceContent />
    </PageShell>
  );
}

export function WatchlistContent() {
  return (
    <PageShell eyebrow="Saved Research" title="Watchlist" description="Save companies, ETFs, themes, famous takes and insider-activity ideas for later research.">
      <div className="grid gap-4 tablet:grid-cols-2 desktop:grid-cols-3">
        {exploreIdeas.slice(0, 3).map((idea) => <IdeaCard key={idea.title} idea={idea} />)}
      </div>
    </PageShell>
  );
}

export function Footer() {
  return (
    <footer className="mt-12 border-t border-white/10 bg-[#111111] px-5 py-10 tablet:px-8 desktop:px-12">
      <div className="mx-auto grid max-w-[1480px] gap-8 tablet:grid-cols-2 laptop:grid-cols-5">
        {footerColumns.map((column) => (
          <div key={column.title}>
            <h3 className="mb-4 text-sm font-semibold text-slate-500">{column.title}</h3>
            <ul className="space-y-3">
              {column.links.map((link) => (
                <li key={link}><a className="text-sm font-semibold text-slate-100 hover:text-amber-200" href="#">{link}</a></li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="mx-auto mt-10 grid max-w-[1480px] gap-6 border-t border-white/10 pt-6 text-sm leading-6 text-slate-500 laptop:grid-cols-[1.5fr_1fr]">
        <p>Quantifi is an educational market research and analytics platform. Information shown is for general informational purposes only and should not be treated as financial advice, investment advice, trading advice, or a recommendation to buy, sell or hold any security. Market data, news, financial information, insider activity and portfolio insights may be delayed, incomplete or inaccurate. Users should independently verify all information and consult a qualified financial adviser before making investment decisions.</p>
        <div>
          <p>© 2026 Quantifi. All rights reserved.</p>
          <div className="mt-3 flex flex-wrap gap-4">
            <a href="#">Terms and Conditions</a>
            <a href="#">Privacy Policy</a>
            <a href="#">AI Terms</a>
            <a href="#">Risk Disclosure</a>
          </div>
        </div>
      </div>
    </footer>
  );
}

export const navIconMap = {
  portfolio: BriefcaseBusiness,
  ideas: Sparkles,
  news: Newspaper,
  insider: Users,
  explore: Search,
  famous: Eye,
  analysis: ChartNoAxesCombined,
  watchlist: CircleDollarSign,
  markets: Building2,
  trading: TrendingUp,
};
