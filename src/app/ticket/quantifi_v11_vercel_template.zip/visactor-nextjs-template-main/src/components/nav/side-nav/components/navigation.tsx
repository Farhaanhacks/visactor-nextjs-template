"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { navigations } from "@/config/site";
import { cn } from "@/lib/utils";

export default function Navigation() {
  const pathname = usePathname();
  return (
    <nav className="flex flex-grow flex-col gap-y-1 p-2">
      {navigations.map((navigation) => {
        const Icon = navigation.icon;
        const active = pathname === navigation.href || (navigation.href !== "/" && pathname.startsWith(navigation.href));
        return (
          <Link
            key={navigation.name}
            href={navigation.href}
            className={cn(
              "flex items-center rounded-md px-3 py-2.5 text-sm font-semibold transition hover:bg-slate-200 dark:hover:bg-slate-800",
              active ? "bg-slate-200 text-slate-950 dark:bg-slate-800 dark:text-white" : "bg-transparent text-slate-700 dark:text-slate-300",
            )}
          >
            <Icon size={16} className="mr-2 text-amber-300" />
            <span>{navigation.name}</span>
          </Link>
        );
      })}
    </nav>
  );
}
