import Link from "next/link";

export default function VisActor() {
  return (
    <Link
      href="/stock-analysis"
      className="relative my-2 flex flex-col justify-center gap-y-2 px-4 py-4"
    >
      <div className="dot-matrix absolute left-0 top-0 -z-10 h-full w-full" />
      <span className="text-xs text-muted-foreground">Beta access</span>
      <div className="text-sm font-semibold text-accent-foreground">
        ₹30 early access
      </div>
      <span className="text-xs text-muted-foreground">Unlock more research modules</span>
    </Link>
  );
}
