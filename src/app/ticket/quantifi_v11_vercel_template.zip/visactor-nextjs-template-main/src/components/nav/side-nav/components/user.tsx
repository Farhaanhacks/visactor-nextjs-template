import { ChevronDown } from "lucide-react";

export default function User() {
  return (
    <div className="flex h-16 items-center border-b border-border px-2">
      <div className="flex w-full items-center justify-between rounded-md px-2 py-1 hover:bg-slate-200 dark:hover:bg-slate-800">
        <div className="flex items-center">
          <div className="mr-2 grid h-9 w-9 place-items-center rounded-full bg-gradient-to-br from-amber-200 via-emerald-300 to-sky-400 text-sm font-black text-slate-950">
            Q
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-bold">Quantifi</span>
            <span className="text-xs text-muted-foreground">Market beta</span>
          </div>
        </div>
        <ChevronDown size={16} />
      </div>
    </div>
  );
}
