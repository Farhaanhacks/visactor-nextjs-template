export const portfolioHoldings = [
  {
    ticker: "NVDA",
    company: "NVIDIA",
    sector: "Technology",
    industry: "Semiconductors",
    weight: 46.1,
    value: "US$25.6k",
    oneWeek: 1.8,
    oneYear: 42.4,
    geography: [
      { name: "North America", value: 41.8, color: "#6ee7d2" },
      { name: "Asia-Pacific", value: 38.4, color: "#60a5fa" },
      { name: "Europe", value: 8.9, color: "#f59e0b" },
      { name: "Not Reported", value: 10.9, color: "#bd4a95" },
    ],
  },
  {
    ticker: "AMZN",
    company: "Amazon",
    sector: "Consumer Discretionary",
    industry: "General Merchandise and Department Stores",
    weight: 53.9,
    value: "US$30k",
    oneWeek: 0.7,
    oneYear: 13.8,
    geography: [
      { name: "North America", value: 34.2, color: "#6ee7d2" },
      { name: "Asia-Pacific", value: 11.2, color: "#bd4a95" },
      { name: "Not Reported", value: 53.9, color: "#60a5fa" },
      { name: "Other", value: 0.7, color: "#f8d56b" },
    ],
  },
];

export const exploreIdeas = [
  {
    title: "Recent Global IPOs",
    description: "Newly listed companies attracting early market attention.",
    companies: 24,
    newCount: 3,
    theme: "IPO",
    tickers: ["ARM", "CAVA", "RDDT", "BIRK"],
    accent: "from-amber-400 to-orange-500",
  },
  {
    title: "Global Space Race Stocks",
    description: "Public-market exposure to satellites, launch systems and space infrastructure.",
    companies: 32,
    newCount: 0,
    theme: "Space",
    tickers: ["RKLB", "ASTS", "LUNR", "ARKX"],
    accent: "from-sky-400 to-indigo-500",
  },
  {
    title: "Undiscovered Gems With Strong Fundamentals",
    description: "Smaller companies with healthy margins, balance sheets and growth signals.",
    companies: 211,
    newCount: 22,
    theme: "Quality",
    tickers: ["FIX", "ONTO", "MEDP", "CELH"],
    accent: "from-emerald-300 to-yellow-400",
  },
  {
    title: "Artificial Intelligence Infrastructure",
    description: "Semiconductors, cloud, networking and data-center power plays.",
    companies: 67,
    newCount: 8,
    theme: "AI",
    tickers: ["NVDA", "AMD", "MSFT", "AVGO"],
    accent: "from-violet-400 to-cyan-400",
  },
  {
    title: "Dividend Powerhouses",
    description: "Income-focused companies with dividend history and payout discipline.",
    companies: 143,
    newCount: 11,
    theme: "Income",
    tickers: ["PG", "KO", "JNJ", "MCD"],
    accent: "from-lime-300 to-emerald-500",
  },
  {
    title: "Insider Buying Watchlist",
    description: "Companies where insider or promoter activity deserves a closer look.",
    companies: 39,
    newCount: 6,
    theme: "Insiders",
    tickers: ["SNOW", "PYPL", "INTC", "BABA"],
    accent: "from-pink-400 to-rose-500",
  },
];

export const newsItems = [
  {
    headline: "AI infrastructure spending keeps accelerating across cloud and chip suppliers",
    source: "Market desk",
    tone: "Mixed",
    summary: "The story is positive for AI infrastructure demand, but investors are watching whether capex converts into durable free cash flow.",
    affected: ["NVDA", "AMD", "MSFT", "AMZN", "GOOGL", "SMH", "SOXX"],
    why: "Chip suppliers, hyperscalers and AI ETFs are exposed to the same demand cycle.",
  },
  {
    headline: "Retail and cloud businesses pull Amazon in different directions",
    source: "Quantifi News Scan",
    tone: "Neutral",
    summary: "Amazon’s portfolio impact comes from both consumer demand and AWS spending trends.",
    affected: ["AMZN", "WMT", "MSFT", "GOOGL"],
    why: "Consumer discretionary and cloud infrastructure both influence Amazon’s valuation narrative.",
  },
  {
    headline: "Semiconductor names react to export-control and data-center headlines",
    source: "Sector Watch",
    tone: "Risk watch",
    summary: "Policy and supply-chain changes can move chip stocks even when company fundamentals remain strong.",
    affected: ["NVDA", "AMD", "AVGO", "TSM", "ASML"],
    why: "These stocks share global supply-chain and geopolitical sensitivity.",
  },
];

export const insiderActivity = [
  {
    ticker: "SNOW",
    company: "Snowflake",
    type: "Insider buying",
    value: "$2.1M",
    date: "Recent filing",
    signal: "Positive watch",
    interpretation: "Insider buying can signal confidence, but confirm with revenue growth, margins and valuation.",
  },
  {
    ticker: "NVDA",
    company: "NVIDIA",
    type: "Planned sale / routine selling",
    value: "$18.4M",
    date: "Recent filing",
    signal: "Neutral",
    interpretation: "Large technology executives often sell under planned programs; repeated selling still deserves monitoring.",
  },
  {
    ticker: "AMZN",
    company: "Amazon",
    type: "Director transaction",
    value: "$6.7M",
    date: "Recent filing",
    signal: "Review",
    interpretation: "Check whether activity is routine liquidity, compensation-related, or a meaningful change in conviction.",
  },
  {
    ticker: "RELIANCE.NS",
    company: "Reliance Industries",
    type: "Promoter / pledge disclosure",
    value: "Source filing required",
    date: "India disclosure layer",
    signal: "India pipeline",
    interpretation: "For Indian stocks, Quantifi should connect BSE/NSE PIT, SAST and pledge disclosures.",
  },
];

export const famousTakes = [
  {
    title: "Michael Burry’s AI Bubble Lens",
    take: "AI can be real and still be overpriced. The risk is that investors pay today for future profits that are not yet proven.",
    watch: [
      "AI infrastructure capex rising faster than free cash flow",
      "Very high valuation multiples",
      "Customer demand that depends on vendor financing",
      "One theme dominating portfolio exposure",
    ],
    affected: ["NVDA", "AMD", "PLTR", "ORCL", "MSFT", "META", "GOOGL", "AMZN", "SMH", "SOXX", "QQQ"],
    takeaway: "Use this as a risk lens, not an automatic sell signal. If your portfolio is AI-heavy, check valuation, debt, revenue quality and customer concentration.",
  },
  {
    title: "Vendor Financing / Circular AI Money Loop",
    take: "Some AI companies, chip suppliers, cloud firms and infrastructure players invest in or finance customers who then buy their products. That can make demand look stronger than it is if the loop becomes too circular.",
    watch: [
      "Supplier invests in customer or neocloud",
      "Customer signs chip/cloud contracts",
      "Supplier reports demand strength",
      "Market capitalizes the whole loop at higher multiples",
    ],
    affected: ["NVDA", "AMD", "ORCL", "MSFT", "AMZN", "GOOGL", "META", "AVGO", "TSM"],
    takeaway: "This is not automatically fraud. It is a financing-risk check: is demand organic, or partly funded by the vendors benefiting from it?",
  },
];

export const dataSources = [
  {
    name: "Yahoo Finance",
    use: "Quick global stock data, historical prices, dividends, splits and basic financial statements.",
    role: "MVP market-data layer",
  },
  {
    name: "SEC EDGAR",
    use: "Free U.S. filings, XBRL company facts, 10-K, 10-Q, 8-K and filing history.",
    role: "Core fundamentals and filings layer",
  },
  {
    name: "Quartr",
    use: "Earnings calls, transcripts, slide decks, event summaries and investor-presentation context.",
    role: "Qualitative earnings layer",
  },
  {
    name: "Trading Economics",
    use: "Sovereign credit ratings, country risk, macroeconomic indicators and global market context.",
    role: "Macro and credit layer",
  },
  {
    name: "Koyfin",
    use: "Advanced charts, dashboards, financial analysis and screener UX inspiration.",
    role: "Benchmark / visual inspiration",
  },
  {
    name: "TIKR Terminal",
    use: "Global stock coverage, analyst estimates, valuation models and deep company research benchmarks.",
    role: "Benchmark / later data reference",
  },
  {
    name: "Macrotrends",
    use: "Long-term historical ratio checks like debt-to-equity and basic financial health validation.",
    role: "Reference / sanity-check layer",
  },
];

export const footerColumns = [
  {
    title: "Markets",
    links: ["US: NYSE & NASDAQ", "India: NSE & BSE", "UK: FTSE", "Canada: TSX", "Australia: ASX", "Japan: NIKKEI", "Germany: DAX", "Crypto & Digital Assets"],
  },
  {
    title: "Investing Ideas",
    links: ["Undervalued Companies", "Dividend Powerhouses", "Insider Activity", "Artificial Intelligence", "Nuclear Energy", "Autonomous Vehicles", "Cybersecurity", "More Ideas"],
  },
  {
    title: "Features & Tools",
    links: ["Portfolio Tracker", "Stock Analysis", "Stock Screener & Alerts", "Trading Ideas", "News Impact", "Insider Activity", "Dividend Tracker", "Explore Companies / ETFs"],
  },
  {
    title: "News & Discovery",
    links: ["Latest Stock News", "Stocks Affected", "Global Market Insights", "Market Movers", "Famous Investor Takes", "Community Narratives", "What’s New"],
  },
  {
    title: "Quantifi",
    links: ["Plans & Pricing", "About Us", "Contact Us", "Help Center", "Learn Stock Investing", "Affiliate Program", "Business & Enterprise"],
  },
];
