# Quantifi changes added to the uploaded ZIP

## Product/UI changes

- Rebranded the template from VisActor to Quantifi.
- Changed the dashboard into a market intelligence website.
- Renamed Stock 360 to Stock Analysis.
- Removed the generic ticket/support dashboard feel.
- Added a professional dark investing-style layout.
- Added a multi-column footer with markets, investing ideas, tools, discovery links, company links and risk disclaimer.

## Pages added

- `/` — Portfolio Stocks homepage
- `/portfolio` — same Portfolio Stocks homepage
- `/ideas` — Trading / Investing Ideas
- `/news` — News Impact + stocks affected
- `/insider-activity` — Insider Activity
- `/explore` — Explore Companies / ETFs
- `/famous-takes` — Michael Burry AI bubble lens + vendor-financing loop
- `/stock-analysis` — Stock Analysis page
- `/watchlist` — Watchlist

## Modules added

- Portfolio Stocks table
- Portfolio diagnosis
- Diversification across industries using Sankey-style flow
- Diversification across holdings using donut chart
- Revenue diversification by geography using donut chart
- Explore More Companies / ETFs cards
- Trading Ideas cards
- News Impact cards with stocks affected
- Insider Activity cards
- Famous Takes cards
- Data Source Plan section

## Data-source roadmap included

- Yahoo Finance — market/price layer
- SEC EDGAR — filings/fundamentals layer
- Quartr — transcripts/earnings call layer
- Trading Economics — macro/credit layer
- Koyfin — benchmark/design inspiration
- TIKR — benchmark/deep stock analysis inspiration
- Macrotrends — long-term ratio sanity-check layer
